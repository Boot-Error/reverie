(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
680: (function (__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(259);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/index.js
var react = __webpack_require__(363);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-dom@19.2.0_react@19.2.0/node_modules/react-dom/client.js
var client = __webpack_require__(546);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1/node_modules/react-redux/dist/react-redux.mjs
var react_redux = __webpack_require__(120);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/index.css
// extracted by css-extract-rspack-plugin

// EXTERNAL MODULE: ./node_modules/.pnpm/@reduxjs+toolkit@2.9.2_react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1__react@19.2.0/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs + 3 modules
var redux_toolkit_modern = __webpack_require__(617);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/effects/dist/redux-saga-core-effects.esm.js
var redux_saga_core_effects_esm = __webpack_require__(827);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/dist/redux-saga-core.esm.js + 2 modules
var redux_saga_core_esm = __webpack_require__(189);
// EXTERNAL MODULE: ./node_modules/.pnpm/reselect@5.1.1/node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(526);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/app/app.slice.ts

const APP_FEATURE_KEY = 'app';
const initialAppState = {
    page: 'HOME'
};
const appSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: APP_FEATURE_KEY,
    initialState: initialAppState,
    reducers: {
        setPage (state, action) {
            return {
                ...state,
                page: action.payload
            };
        }
    }
});
const appSliceActions = appSlice.actions;
const appSliceReducer = appSlice.reducer;
const getAppState = (rootState)=>rootState[APP_FEATURE_KEY];
/* Selectors */ const appSliceSelectors = {
    getCurrentPage: (0,reselect/* .createSelector */.Mz)(getAppState, (state)=>state.page)
};

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/store.ts




const sagaMiddleware = (0,redux_saga_core_esm/* ["default"] */.Ay)();
const store_store = (0,redux_toolkit_modern/* .configureStore */.U1)({
    reducer: {
        [APP_FEATURE_KEY]: appSliceReducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(sagaMiddleware),
    devTools: true
});
function* rootSaga() {
    yield (0,redux_saga_core_effects_esm/* .all */.Q7)([]);
}
sagaMiddleware.run(rootSaga);
function getStore() {
    return store_store;
}

// EXTERNAL MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
var _define_property = __webpack_require__(925);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/constants/app-pages.constant.ts

class AppPages {
}
(0,_define_property._)(AppPages, "HOME", 'HOME');

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card/history-collection-card.tsx

function HistoryCollectionCardWidget(props) {
    const cardTitle = props.cardDetails.cardTitle;
    const themeIcon = props.cardDetails.themeIcon;
    const handleJumpBackIn = ()=>{};
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full max-w-sm p-6 bg-white border-2 border-purple-700 rounded-2xl font-sans shadow-[4px_4px_0px_theme(colors.purple.700)]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center mb-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-12 h-12 rounded-full border-2 border-purple-700 mr-4 shrink-0 flex items-center justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                            className: "text-lg",
                            children: themeIcon
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-xl font-medium text-slate-900",
                        children: cardTitle
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "pl-12 mb-10",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "grid grid-cols-2 gap-x-4 gap-y-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                            className: "text-base text-slate-600",
                            children: "myntra.com"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                            className: "text-base text-slate-600",
                            children: "nykaa.com"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                            className: "text-base text-slate-600",
                            children: "tatacliq.com"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    className: "px-4 py-2 text-sm font-medium text-slate-900 bg-lime-400 border-2 border-lime-600 rounded-lg shadow-[2px_2px_0px_theme(colors.lime.600)] hover:bg-lime-300 active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all",
                    onClick: handleJumpBackIn,
                    children: "Jump Back ->"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/histoy-collection-card-board/constants.ts
const themes = [
    {
        id: 't1',
        name: 'Light',
        description: 'Light color scheme with soft backgrounds'
    },
    {
        id: 't2',
        name: 'Dark',
        description: 'Dark color scheme with high contrast'
    },
    {
        id: 't3',
        name: 'Nature',
        description: 'Green and earthy tones for nature websites'
    },
    {
        id: 't4',
        name: 'Tech',
        description: 'Modern technology-themed style'
    },
    {
        id: 't5',
        name: 'Minimal',
        description: 'Minimalist and clean layout'
    }
];
const webPages = [
    {
        domain: 'example.com',
        favicon: 'https://example.com/favicon.ico',
        theme: themes[0],
        navigateUrl: 'https://example.com/home'
    },
    {
        domain: 'darksite.org',
        favicon: 'https://darksite.org/favicon.ico',
        theme: themes[1],
        navigateUrl: 'https://darksite.org/dashboard'
    },
    {
        domain: 'natureblog.net',
        favicon: 'https://natureblog.net/favicon.ico',
        theme: themes[2],
        navigateUrl: 'https://natureblog.net/posts'
    },
    {
        domain: 'techupdates.io',
        favicon: 'https://techupdates.io/favicon.ico',
        theme: themes[3],
        navigateUrl: 'https://techupdates.io/latest'
    },
    {
        domain: 'minimaldesign.com',
        favicon: 'https://minimaldesign.com/favicon.ico',
        theme: themes[4],
        navigateUrl: 'https://minimaldesign.com/gallery'
    }
];
const historyCards = [
    {
        cardTitle: 'Work Tools',
        cardDescription: 'Frequently used productivity and work websites',
        themeIcon: '💻',
        webPageDetails: [
            webPages[0],
            webPages[1]
        ]
    },
    {
        cardTitle: 'Personal Blogs',
        cardDescription: 'Blogs and personal projects I follow',
        themeIcon: '✍️',
        webPageDetails: [
            webPages[2],
            webPages[4]
        ]
    },
    {
        cardTitle: 'Tech News',
        cardDescription: 'Latest technology updates and articles',
        themeIcon: '📰',
        webPageDetails: [
            webPages[3]
        ]
    },
    {
        cardTitle: 'Mixed Collection',
        cardDescription: 'A mix of different websites for testing',
        themeIcon: '🧩',
        webPageDetails: [
            webPages[0],
            webPages[2],
            webPages[3],
            webPages[4]
        ]
    }
];

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/histoy-collection-card-board/history-collection-card-board.tsx



function HistoryCollectionCardBoardWidget(props) {
    const cards = historyCards.map((card)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardWidget, {
            cardDetails: card
        }));
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl",
        children: cards
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/home-page/home-page.tsx



function HomePage(props) {
    (0,react.useEffect)(()=>{
    // const pipe = ChromeMessagingPipe.new<{ url: string }>({ name: 'test' });
    // pipe.subscribe(({ url }) => {
    //   console.log({ url });
    // });
    // return () => {};
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "min-h-screen bg-gray-50 flex flex-col items-center py-16 px-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                className: "text-5xl font-bold text-gray-800 mb-6 text-center",
                children: "Browse what you have already browsed.."
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full max-w-xl mb-12",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                    type: "text",
                    placeholder: "Search...",
                    className: "w-full px-6 py-3 rounded-full border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardBoardWidget, {})
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/page-manager/page-manager.tsx





function PageManagerWidget(props) {
    const currentPage = (0,react_redux/* .useSelector */.d4)(appSliceSelectors.getCurrentPage);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        children: currentPage === AppPages.HOME && /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {})
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/main.tsx







const container = document.getElementById('root');
if (container) {
    const store = getStore();
    const root = (0,client.createRoot)(container);
    root.render(/*#__PURE__*/ (0,jsx_runtime.jsx)(react.StrictMode, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_redux/* .Provider */.Kq, {
            store: store,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PageManagerWidget, {})
        })
    }));
}


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/on_chunk_loaded
(() => {
var deferred = [];
__webpack_require__.O = (result, chunkIds, fn, priority) => {
	if (chunkIds) {
		priority = priority || 0;
		for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
			deferred[i] = deferred[i - 1];
		deferred[i] = [chunkIds, fn, priority];
		return;
	}
	var notFulfilled = Infinity;
	for (var i = 0; i < deferred.length; i++) {
		var [chunkIds, fn, priority] = deferred[i];
		var fulfilled = true;
		for (var j = 0; j < chunkIds.length; j++) {
			if (
				(priority & (1 === 0) || notFulfilled >= priority) &&
				Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))
			) {
				chunkIds.splice(j--, 1);
			} else {
				fulfilled = false;
				if (priority < notFulfilled) notFulfilled = priority;
			}
		}
		if (fulfilled) {
			deferred.splice(i--, 1);
			var r = fn();
			if (r !== undefined) result = r;
		}
	}
	return result;
};

})();
// webpack/runtime/jsonp_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"89": 0,};
      __webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
// install a JSONP callback for chunk loading
var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
	var [chunkIds, moreModules, runtime] = data;
	// add "moreModules" to the modules object,
	// then flag all "chunkIds" as loaded and fire callback
	var moduleId, chunkId, i = 0;
	if (chunkIds.some((id) => (installedChunks[id] !== 0))) {
		for (moduleId in moreModules) {
			if (__webpack_require__.o(moreModules, moduleId)) {
				__webpack_require__.m[moduleId] = moreModules[moduleId];
			}
		}
		if (runtime) var result = runtime(__webpack_require__);
	}
	if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
	for (; i < chunkIds.length; i++) {
		chunkId = chunkIds[i];
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId]
		) {
			installedChunks[chunkId][0]();
		}
		installedChunks[chunkId] = 0;
	}
	return __webpack_require__.O(result);
};

var chunkLoadingGlobal = self["webpackChunkreverie"] = self["webpackChunkreverie"] || [];
chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));

})();
/************************************************************************/
// startup
// Load entry module and return exports
// This entry module depends on other loaded chunks and execution need to be delayed
var __webpack_exports__ = __webpack_require__.O(undefined, ["783", "337", "533"], function() { return __webpack_require__(680) });
__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
})()
;
//# sourceMappingURL=search-dashboard.js.map