(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
992: (function (__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(259);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/index.js
var react = __webpack_require__(363);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-dom@19.2.0_react@19.2.0/node_modules/react-dom/client.js
var client = __webpack_require__(546);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1/node_modules/react-redux/dist/react-redux.mjs
var react_redux = __webpack_require__(120);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/index.css
// extracted by css-extract-rspack-plugin

// EXTERNAL MODULE: ./node_modules/.pnpm/@reduxjs+toolkit@2.9.2_react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1__react@19.2.0/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var redux_toolkit_modern = __webpack_require__(963);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/effects/dist/redux-saga-core-effects.esm.js
var redux_saga_core_effects_esm = __webpack_require__(827);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/dist/redux-saga-core.esm.js
var redux_saga_core_esm = __webpack_require__(287);
// EXTERNAL MODULE: ./node_modules/.pnpm/reselect@5.1.1/node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(526);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/app/app.slice.ts

const APP_FEATURE_KEY = 'app';
const initialAppState = {
    page: 'HOME'
};
const appSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: APP_FEATURE_KEY,
    initialState: initialAppState,
    reducers: {
        setPage (state, action) {
            return {
                ...state,
                page: action.payload
            };
        }
    }
});
const appSliceActions = appSlice.actions;
const appSliceReducer = appSlice.reducer;
const getAppState = (rootState)=>rootState[APP_FEATURE_KEY];
/* Selectors */ const appSliceSelectors = {
    getCurrentPage: (0,reselect/* .createSelector */.Mz)(getAppState, (state)=>state.page)
};

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-collection-board/history-collection-board.slice.ts

const HISTORY_COLLECTION_BOARD_FEATURE_KEY = 'history-collection-board';
const initialHistortCollectionBoardState = {
    clusters: {}
};
const historyCollectionBoardSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: HISTORY_COLLECTION_BOARD_FEATURE_KEY,
    initialState: initialHistortCollectionBoardState,
    reducers: {
        setBoard (state, action) {
            return {
                ...state,
                clusters: action.payload.clusters
            };
        }
    }
});
const historyCollectionBoardSliceActions = historyCollectionBoardSlice.actions;
const historyCollectionBoardSliceReducer = historyCollectionBoardSlice.reducer;
const getHistoryCollectionBoardState = (rootState)=>rootState[HISTORY_COLLECTION_BOARD_FEATURE_KEY];
/* Selectors */ const historyCollectionBoardSliceSelectors = {
    getBoard: (0,reselect/* .createSelector */.Mz)(getHistoryCollectionBoardState, (state)=>state.clusters)
};

// EXTERNAL MODULE: ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/lodash.js
var lodash = __webpack_require__(935);
;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    if (message.name === name) {
                        await callback({
                            sender
                        }, payload);
                    }
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/common/messaging/history-collection-channel/history-collection-channel.ts

function makeHistoryCollectionBoardChannel() {
    return newMessageChannel('HISTORY_COLLECTION_CARD');
}

// EXTERNAL MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
var esm_define_property = __webpack_require__(925);
;// CONCATENATED MODULE: ./src/common/constants/internet-cluster-themes.ts
const internetThemes = [
    {
        id: 1,
        theme: 'Information Seeking',
        icon: 'search',
        colors: {
            primary: '#1565C0',
            accent: '#42A5F5',
            textOnAccent: '#FFFFFF'
        },
        description: 'Users search for knowledge such as news updates, tutorials, documentation, or research content to satisfy curiosity or accomplish specific tasks.'
    },
    {
        id: 2,
        theme: 'Entertainment Consumption',
        icon: 'movie',
        colors: {
            primary: '#D32F2F',
            accent: '#FF5252',
            textOnAccent: '#FFFFFF'
        },
        description: 'Includes watching videos, browsing social media, listening to music, reading memes, or playing online games for relaxation and leisure.'
    },
    {
        id: 3,
        theme: 'Shopping and Product Research',
        icon: 'shopping_cart',
        colors: {
            primary: '#2E7D32',
            accent: '#66BB6A',
            textOnAccent: '#FFFFFF'
        },
        description: 'Users explore e-commerce sites, compare prices, read product reviews, and look for deals before making purchasing decisions.'
    },
    {
        id: 4,
        theme: 'Social Connection',
        icon: 'chat',
        colors: {
            primary: '#7B1FA2',
            accent: '#AB47BC',
            textOnAccent: '#FFFFFF'
        },
        description: 'Covers engagement on social media platforms, messaging apps, or online communities to stay connected with friends, family, and interest groups.'
    },
    {
        id: 5,
        theme: 'Learning and Skill Development',
        icon: 'school',
        colors: {
            primary: '#F9A825',
            accent: '#FFD54F',
            textOnAccent: '#212121'
        },
        description: 'Users visit educational platforms, online courses, or tutorials to build professional skills or learn new topics for personal growth.'
    },
    {
        id: 6,
        theme: 'Productivity and Work-Related Tasks',
        icon: 'work',
        colors: {
            primary: '#37474F',
            accent: '#90A4AE',
            textOnAccent: '#FFFFFF'
        },
        description: 'Involves browsing tools, documentation, and platforms used for collaboration, project management, and professional work.'
    },
    {
        id: 7,
        theme: 'Personal Expression and Creation',
        icon: 'palette',
        colors: {
            primary: '#EF6C00',
            accent: '#FFA726',
            textOnAccent: '#212121'
        },
        description: 'Users express creativity through blogging, digital art, content creation, or sharing personal opinions online.'
    }
];

;// CONCATENATED MODULE: ./src/common/datastore/clustered-webpages-db.ts

// export class ClusteredWebpagesDb {
//   private static instance: ClusteredWebpagesDb;
//   private clusters: Map<string, ClusterDetails> = new Map();
//   private constructor() {}
//   public static getInstance(): ClusteredWebpagesDb {
//     if (!ClusteredWebpagesDb.instance) {
//       ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
//     }
//     return ClusteredWebpagesDb.instance;
//   }
//   public addCluster(clusterDetails: ClusterDetails) {
//     this.clusters.set(clusterDetails.name, clusterDetails);
//   }
//   public getAllClusters(): Array<ClusterDetails> {
//     return Array.from(this.clusters.values());
//   }
// }
class ClusteredWebpagesDb {
    static getInstance() {
        if (!ClusteredWebpagesDb.instance) {
            ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
        }
        return ClusteredWebpagesDb.instance;
    }
    /**
   * Add or update a cluster in chrome.storage.local
   */ async addClusters(clusters) {
        const previousClusters = await this.getAllClustersAsMap();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    async setClusters(clusters) {
        const previousClusters = new Map();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    /**
   * Retrieve all clusters from chrome.storage.local
   */ async getAllClusters() {
        const clusters = await this.getAllClustersAsMap();
        return Array.from(clusters.values());
    }
    /**
   * Internal: Retrieve all clusters as a Map
   */ async getAllClustersAsMap() {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                ClusteredWebpagesDb.STORAGE_KEY
            ], (result)=>{
                const stored = result[ClusteredWebpagesDb.STORAGE_KEY] || {};
                const map = new Map(Object.entries(stored));
                resolve(map);
            });
        });
    }
    /**
   * Internal: Save clusters map back to chrome.storage.local
   */ async saveClustersToStorage(clusters) {
        return new Promise((resolve)=>{
            const obj = Object.fromEntries(clusters);
            chrome.storage.local.set({
                [ClusteredWebpagesDb.STORAGE_KEY]: obj
            }, ()=>resolve());
        });
    }
    constructor(){}
}
(0,esm_define_property._)(ClusteredWebpagesDb, "instance", void 0);
(0,esm_define_property._)(ClusteredWebpagesDb, "STORAGE_KEY", 'clusters');

;// CONCATENATED MODULE: ./src/common/datastore/tab-content-db.ts

// export class TabContentDb {
//   private static instance: TabContentDb;
//   // private db: IDBDatabase;
//   private tabContentProcessed: Map<string, TabContentProcessedDetails> =
//     new Map();
//   private tabCluster: Map<string, string> = new Map();
//   private constructor() {
//     // (async () => {
//     //   await this.setupDb();
//     // })();
//   }
//   public static getInstance(): TabContentDb {
//     if (!TabContentDb.instance) {
//       TabContentDb.instance = new TabContentDb();
//     }
//     return TabContentDb.instance;
//   }
//   public async addTabContent(tabContentDetails: TabContentProcessedDetails) {
//     const url = tabContentDetails.url;
//     this.tabContentProcessed.set(url, tabContentDetails);
//     // const db = await this.getDb();
//     // const transaction = db.transaction('tab-content-processed', 'readwrite');
//     // const row = transaction.objectStore('tab-content-processed');
//     // const request = row.add(tabContentDetails);
//     // request.onsuccess = async () => {
//     //   console.log('tab added');
//     // };
//     // request.onerror = async () => {
//     //   console.error('Error adding tab', request.error);
//     // };
//   }
//   public addClusterToDocument(url: string, cluster: string) {
//     this.tabCluster.set(url, cluster);
//     chrome.storage.local.set()
//   }
//   public hasCluster(url: string) {
//     return this.tabCluster.has(url);
//   }
//   public getAllThemes(): Array<string> {
//     return Array.from(this.tabContentProcessed.values())
//       .map((row: TabContentProcessedDetails) => row.contentThemes)
//       .reduce((acc, themes) => {
//         return [...acc, ...themes.filter((theme) => !acc.includes(theme))];
//       }, []);
//   }
//   public getAllTabs() {
//     return Array.from(this.tabContentProcessed.keys());
//   }
//   public getAllTabsOfCluster(
//     clusterName: string,
//   ): Array<TabContentProcessedDetails> {
//     return Array.from(this.tabCluster.keys())
//       .filter((url) => this.tabCluster.get(url) === clusterName)
//       .map((url) => this.tabContentProcessed.get(url))
//       .filter((t) => t !== undefined);
//   }
//   public getTabContentByUrl(
//     url: string,
//   ): TabContentProcessedDetails | undefined {
//     return this.tabContentProcessed.get(url);
//   }
// }
class TabContentDb {
    static getInstance() {
        if (!TabContentDb.instance) {
            TabContentDb.instance = new TabContentDb();
        }
        return TabContentDb.instance;
    }
    /** Helper to get data from chrome.storage.local */ async getFromStorage(key) {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                key
            ], (result)=>{
                resolve(result[key]);
            });
        });
    }
    /** Helper to set data in chrome.storage.local */ async setInStorage(key, value) {
        return new Promise((resolve)=>{
            chrome.storage.local.set({
                [key]: value
            }, ()=>resolve());
        });
    }
    /** Add or update tab content details */ async addTabContent(tabContentDetails) {
        const url = tabContentDetails.url;
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        stored[url] = tabContentDetails;
        await this.setInStorage('tabContentProcessed', stored);
    }
    /** Add or update cluster mapping for a URL */ async addClusterToDocument(url, cluster) {
        const stored = await this.getFromStorage('tabCluster') || {};
        stored[url] = cluster;
        await this.setInStorage('tabCluster', stored);
    }
    /** Check if a cluster exists for a given URL */ async hasCluster(url) {
        const stored = await this.getFromStorage('tabCluster') || {};
        return stored.hasOwnProperty(url);
    }
    /** Get all unique content themes */ async getAllThemes() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        const allThemes = Object.values(stored).map((row)=>row.contentThemes).flat();
        // Deduplicate
        return Array.from(new Set(allThemes));
    }
    /** Get all stored tab URLs */ async getAllTabs() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(stored);
    }
    /** Get all tab contents belonging to a specific cluster */ async getAllTabsOfCluster(clusterName) {
        const tabCluster = await this.getFromStorage('tabCluster') || {};
        const tabContentProcessed = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(tabCluster).filter((url)=>tabCluster[url] === clusterName).map((url)=>tabContentProcessed[url]).filter((t)=>!!t);
    }
    /** Get tab content by URL */ async getTabContentByUrl(url) {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return stored[url];
    }
    constructor(){}
}
(0,esm_define_property._)(TabContentDb, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/history-collection-card/history-collection-card.ts




class HistoryCollectionBoard {
    static getInstance() {
        if (!HistoryCollectionBoard.instance) {
            HistoryCollectionBoard.instance = new HistoryCollectionBoard();
        }
        return HistoryCollectionBoard.instance;
    }
    async getHistoryBoard() {
        const clusters = await ClusteredWebpagesDb.getInstance().getAllClusters();
        const historyCollectionCards = await Promise.all(clusters.map(async (cluster)=>{
            const tabs = await TabContentDb.getInstance().getAllTabsOfCluster(cluster.name);
            console.log('History card', {
                clusters,
                tabs
            });
            if (tabs.length > 0) {
                const historyCollectionCard = await this.getHistoryCollectionCard(cluster, tabs);
                return {
                    clusterName: cluster.name,
                    historyCollectionCard
                };
            }
        }));
        const board = historyCollectionCards.filter((t)=>t !== undefined).reduce((acc, param)=>{
            let { clusterName, historyCollectionCard } = param;
            return {
                ...acc,
                [clusterName]: historyCollectionCard
            };
        }, {});
        return board;
    }
    async getHistoryCollectionCard(cluster, webPageDetails) {
        const collectionThemeDetails = internetThemes.find((themeDetails)=>themeDetails.theme === cluster.collectionTheme) || internetThemes["0"];
        const cardTheme = {
            themeIcon: collectionThemeDetails.icon,
            size: 'M',
            primaryColor: collectionThemeDetails.colors.primary,
            accentColor: collectionThemeDetails.colors.accent,
            textColor: collectionThemeDetails.colors.textOnAccent
        };
        // FIXME: populate this properly
        return {
            cardTitle: cluster.name,
            cardDescription: cluster.description,
            theme: cardTheme,
            webPageDetails: webPageDetails.map((param)=>{
                let { url } = param;
                return {
                    domain: new URL(url).hostname,
                    favicon: '',
                    theme: {
                        id: '',
                        name: '',
                        description: ''
                    },
                    navigateUrl: url
                };
            })
        };
    }
    constructor(){}
}
(0,esm_define_property._)(HistoryCollectionBoard, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-collection-board/history-collection-board.saga.ts







const historyCollectionBoardSagaActions = {
    initiateBoardStateUpdate: (0,redux_toolkit_modern/* .createAction */.VP)(`${HISTORY_COLLECTION_BOARD_FEATURE_KEY}/initiateBoardStateUpdate`),
    openCollectionInTabGroup: (0,redux_toolkit_modern/* .createAction */.VP)(`${HISTORY_COLLECTION_BOARD_FEATURE_KEY}/openCollectionInTabGroup`)
};
const historyCollectionBoardSagaWatchers = [
    (0,redux_saga_core_effects_esm/* .takeLatest */.p8)(historyCollectionBoardSagaActions.initiateBoardStateUpdate.type, initiateBoardStateUpdate),
    (0,redux_saga_core_effects_esm/* .takeLatest */.p8)(historyCollectionBoardSagaActions.openCollectionInTabGroup.type, initiateOpenCollectionInTabGroup)
];
function* initiateBoardStateUpdate() {
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(watchHistoryCollectionBoardEvents);
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(loadHistoryCollectionCardsFromStorage);
}
function* initiateOpenCollectionInTabGroup(action) {
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(openAllWebPagesInTabGroup, action.payload.collectionCard);
}
function* loadHistoryCollectionCardsFromStorage() {
    const clusters = yield (0,redux_saga_core_effects_esm/* .call */.T1)(async ()=>{
        return await HistoryCollectionBoard.getInstance().getHistoryBoard();
    });
    console.log('Clusters from extension storage', clusters);
    yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historyCollectionBoardSliceActions.setBoard({
        clusters
    }));
}
function* openAllWebPagesInTabGroup(collectionCard) {
    const cardDetails = yield (0,redux_saga_core_effects_esm/* .call */.T1)(getCardDetailsByCluster, collectionCard);
    if (cardDetails) {
        cardDetails.webPageDetails.map((param)=>{
            let { navigateUrl } = param;
            chrome.tabs.create({
                url: navigateUrl
            });
        });
    }
}
function* getCardDetailsByCluster(cluster) {
    const clusters = yield (0,redux_saga_core_effects_esm/* .select */.Lt)(historyCollectionBoardSliceSelectors.getBoard);
    return lodash._.get(clusters, [
        cluster
    ]);
}
function createHistoryCollectionBoardChannel() {
    return (0,redux_saga_core_esm/* .eventChannel */.Od)((emit)=>{
        const historyCollectionBoardChannel = makeHistoryCollectionBoardChannel();
        historyCollectionBoardChannel.subscribe({}, async (context, messagePayload)=>{
            emit(messagePayload);
        });
        return ()=>{
            historyCollectionBoardChannel.unsubscribe();
        };
    });
}
function* watchHistoryCollectionBoardEvents() {
    const historyCollectionBoardChannel = yield (0,redux_saga_core_effects_esm/* .call */.T1)(createHistoryCollectionBoardChannel);
    while(true){
        const event = yield (0,redux_saga_core_effects_esm/* .take */.s)(historyCollectionBoardChannel);
        console.log({
            event
        });
        yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historyCollectionBoardSliceActions.setBoard({
            clusters: event.clusters
        }));
    }
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/store.ts






const sagaMiddleware = (0,redux_saga_core_esm/* ["default"] */.Ay)();
const store_store = (0,redux_toolkit_modern/* .configureStore */.U1)({
    reducer: {
        [APP_FEATURE_KEY]: appSliceReducer,
        [HISTORY_COLLECTION_BOARD_FEATURE_KEY]: historyCollectionBoardSliceReducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(sagaMiddleware),
    devTools: true
});
function* rootSaga() {
    yield (0,redux_saga_core_effects_esm/* .all */.Q7)([
        ...historyCollectionBoardSagaWatchers
    ]);
}
sagaMiddleware.run(rootSaga);
function getStore() {
    return store_store;
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/constants/app-pages.constant.ts

class AppPages {
}
(0,esm_define_property._)(AppPages, "HOME", 'HOME');

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card-icon/card-icons.tsx

function RoundPalette(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10a2.5 2.5 0 0 0 2.5-2.5c0-.61-.23-1.2-.64-1.67a.53.53 0 0 1-.13-.33c0-.28.22-.5.5-.5H16c3.31 0 6-2.69 6-6c0-4.96-4.49-9-10-9m5.5 11c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5s1.5.67 1.5 1.5s-.67 1.5-1.5 1.5m-3-4c-.83 0-1.5-.67-1.5-1.5S13.67 6 14.5 6s1.5.67 1.5 1.5S15.33 9 14.5 9M5 11.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5S7.33 13 6.5 13S5 12.33 5 11.5m6-4c0 .83-.67 1.5-1.5 1.5S8 8.33 8 7.5S8.67 6 9.5 6s1.5.67 1.5 1.5"
        })
    });
}
function TwotoneManageSearch(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M2 12h5v2H2zm16.17 1.75c.52-.79.83-1.73.83-2.75c0-2.76-2.24-5-5-5s-5 2.24-5 5s2.24 5 5 5c1.02 0 1.96-.31 2.76-.83L20.59 19L22 17.59zM14 14c-1.65 0-3-1.35-3-3s1.35-3 3-3s3 1.35 3 3s-1.35 3-3 3M2 7h5v2H2zm0 10h10v2H2z"
        })
    });
}
function BaselineMovieFilter(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "m18 4l2 3h-3l-2-3h-2l2 3h-3l-2-3H8l2 3H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4zm-6.75 11.25L10 18l-1.25-2.75L6 14l2.75-1.25L10 10l1.25 2.75L14 14zm5.69-3.31L16 14l-.94-2.06L13 11l2.06-.94L16 8l.94 2.06L19 11z"
        })
    });
}
function BaselineShoppingCart(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2s-.9-2-2-2M1 2v2h2l3.6 7.59l-1.35 2.45c-.16.28-.25.61-.25.96c0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12l.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49A1.003 1.003 0 0 0 20 4H5.21l-.94-2zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2s2-.9 2-2s-.9-2-2-2"
        })
    });
}
function BaselineChat(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2M6 9h12v2H6zm8 5H6v-2h8zm4-6H6V6h12z"
        })
    });
}
function BaselineSchool(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M5 13.18v4L12 21l7-3.82v-4L12 17zM12 3L1 9l11 6l9-4.91V17h2V9z"
        })
    });
}
function BaselineWork(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2m-6 0h-4V4h4z"
        })
    });
}
function BaselineCollectionsBookmark(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                fill: "currentColor",
                d: "M4 6H2v14c0 1.1.9 2 2 2h14v-2H4z"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                fill: "currentColor",
                d: "M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2m0 10l-2.5-1.5L15 12V4h5z"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card-icon/history-collection-card-icon.tsx



function HistoryCollectionCardIcon(props) {
    const iconName = props.iconName;
    const iconColor = props.iconColor;
    const defaultIcon = icons['default'];
    const iconComponent = lodash._.get(icons, [
        iconName
    ], defaultIcon);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        style: {
            color: iconColor
        },
        children: iconComponent
    });
}
const icons = {
    search: /*#__PURE__*/ (0,jsx_runtime.jsx)(TwotoneManageSearch, {}),
    movie: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineMovieFilter, {}),
    shopping_cart: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineShoppingCart, {}),
    chat: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineChat, {}),
    school: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineSchool, {}),
    work: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineWork, {}),
    palette: /*#__PURE__*/ (0,jsx_runtime.jsx)(RoundPalette, {}),
    default: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineCollectionsBookmark, {})
};

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card/history-collection-card.tsx




function HistoryCollectionCardWidget(props) {
    const cardTitle = props.cardDetails.cardTitle;
    const webPageDetails = props.cardDetails.webPageDetails;
    const themeIcon = props.cardDetails.theme.themeIcon;
    const primaryColor = props.cardDetails.theme.primaryColor;
    const accentColor = props.cardDetails.theme.accentColor;
    const textColor = props.cardDetails.theme.textColor;
    const dispatch = (0,react_redux/* .useDispatch */.wA)();
    const links = webPageDetails.reduce((acc, webPage)=>{
        const [_, count] = acc.find((param)=>{
            let [domain, _] = param;
            return domain === webPage.domain;
        }) || [
            webPage.domain,
            0
        ];
        const rest = acc.filter((param)=>{
            let [domain, count] = param;
            return domain !== webPage.domain;
        });
        return [
            ...rest,
            [
                webPage.domain,
                count + 1
            ]
        ];
    }, []).map((param)=>{
        let [domain, count] = param;
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
            className: "text-base text-slate-600",
            children: count > 1 ? `${domain} +${count}` : `${domain}`
        });
    });
    const handleJumpBackIn = (collectionCard)=>{
        dispatch(historyCollectionBoardSagaActions.openCollectionInTabGroup({
            collectionCard
        }));
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full max-w-sm p-6 rounded-2xl font-sans",
        style: {
            backgroundColor: accentColor,
            borderColor: primaryColor,
            color: primaryColor,
            boxShadow: `4px 4px 0px ${primaryColor}`
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center mb-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-12 h-12  mr-4 shrink-0 flex items-center justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardIcon, {
                            iconName: themeIcon,
                            iconColor: primaryColor
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-3xl font-medium",
                        style: {
                            color: textColor
                        },
                        children: cardTitle
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "pl-12 mb-10",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grid grid-cols-1 gap-x-4 gap-y-2",
                    children: links
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    // className="px-4 py-2 text-sm font-medium text-slate-900 bg-lime-400 border-2 border-lime-600 rounded-lg shadow-[2px_2px_0px_theme(colors.lime.600)] hover:bg-lime-300 active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all"
                    className: "px-4 py-2 text-sm font-medium",
                    style: {
                        color: textColor,
                        backgroundColor: accentColor,
                        borderColor: primaryColor
                    },
                    onClick: ()=>handleJumpBackIn(cardTitle),
                    children: "Jump Back ->"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/histoy-collection-card-board/history-collection-card-board.tsx






function HistoryCollectionCardBoardWidget(props) {
    const dispatch = (0,react_redux/* .useDispatch */.wA)();
    (0,react.useEffect)(()=>{
        dispatch(historyCollectionBoardSagaActions.initiateBoardStateUpdate());
    }, []);
    const historyCardsByCluster = (0,react_redux/* .useSelector */.d4)(historyCollectionBoardSliceSelectors.getBoard);
    console.log({
        historyCardsByCluster
    });
    const cards = Object.entries(historyCardsByCluster).map((param)=>{
        let [cluster, card] = param;
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardWidget, {
            cardDetails: card
        });
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl",
        children: cards
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/home-page/home-page.tsx



function HomePage(props) {
    (0,react.useEffect)(()=>{}, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "min-h-screen bg-gray-50 flex flex-col items-center py-16 px-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                className: "text-5xl font-bold text-gray-800 mb-6 text-center",
                children: "Browse what you have already browsed.."
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full max-w-xl mb-12",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                    type: "text",
                    placeholder: "Search...",
                    className: "w-full px-6 py-3 rounded-full border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardBoardWidget, {})
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/page-manager/page-manager.tsx





function PageManagerWidget(props) {
    const currentPage = (0,react_redux/* .useSelector */.d4)(appSliceSelectors.getCurrentPage);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        children: currentPage === AppPages.HOME && /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {})
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/main.tsx







const container = document.getElementById('root');
if (container) {
    const store = getStore();
    const root = (0,client.createRoot)(container);
    root.render(/*#__PURE__*/ (0,jsx_runtime.jsx)(react.StrictMode, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_redux/* .Provider */.Kq, {
            store: store,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PageManagerWidget, {})
        })
    }));
}


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
id: moduleId,
loaded: false,
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);

// Flag the module as loaded
module.loaded = true;
// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/global
(() => {
__webpack_require__.g = (() => {
	if (typeof globalThis === 'object') return globalThis;
	try {
		return this || new Function('return this')();
	} catch (e) {
		if (typeof window === 'object') return window;
	}
})();
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/node_module_decorator
(() => {
__webpack_require__.nmd = (module) => {
  module.paths = [];
  if (!module.children) module.children = [];
  return module;
};
})();
// webpack/runtime/on_chunk_loaded
(() => {
var deferred = [];
__webpack_require__.O = (result, chunkIds, fn, priority) => {
	if (chunkIds) {
		priority = priority || 0;
		for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
			deferred[i] = deferred[i - 1];
		deferred[i] = [chunkIds, fn, priority];
		return;
	}
	var notFulfilled = Infinity;
	for (var i = 0; i < deferred.length; i++) {
		var [chunkIds, fn, priority] = deferred[i];
		var fulfilled = true;
		for (var j = 0; j < chunkIds.length; j++) {
			if (
				(priority & (1 === 0) || notFulfilled >= priority) &&
				Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))
			) {
				chunkIds.splice(j--, 1);
			} else {
				fulfilled = false;
				if (priority < notFulfilled) notFulfilled = priority;
			}
		}
		if (fulfilled) {
			deferred.splice(i--, 1);
			var r = fn();
			if (r !== undefined) result = r;
		}
	}
	return result;
};

})();
// webpack/runtime/jsonp_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"89": 0,};
      __webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
// install a JSONP callback for chunk loading
var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
	var [chunkIds, moreModules, runtime] = data;
	// add "moreModules" to the modules object,
	// then flag all "chunkIds" as loaded and fire callback
	var moduleId, chunkId, i = 0;
	if (chunkIds.some((id) => (installedChunks[id] !== 0))) {
		for (moduleId in moreModules) {
			if (__webpack_require__.o(moreModules, moduleId)) {
				__webpack_require__.m[moduleId] = moreModules[moduleId];
			}
		}
		if (runtime) var result = runtime(__webpack_require__);
	}
	if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
	for (; i < chunkIds.length; i++) {
		chunkId = chunkIds[i];
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId]
		) {
			installedChunks[chunkId][0]();
		}
		installedChunks[chunkId] = 0;
	}
	return __webpack_require__.O(result);
};

var chunkLoadingGlobal = self["webpackChunkreverie"] = self["webpackChunkreverie"] || [];
chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));

})();
/************************************************************************/
// startup
// Load entry module and return exports
// This entry module depends on other loaded chunks and execution need to be delayed
var __webpack_exports__ = __webpack_require__.O(undefined, ["783", "527", "665"], function() { return __webpack_require__(992) });
__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
})()
;
//# sourceMappingURL=search-dashboard.js.map