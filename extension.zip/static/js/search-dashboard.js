(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
660: (function (__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(259);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/index.js
var react = __webpack_require__(363);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-dom@19.2.0_react@19.2.0/node_modules/react-dom/client.js
var client = __webpack_require__(546);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1/node_modules/react-redux/dist/react-redux.mjs
var react_redux = __webpack_require__(120);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/index.css
// extracted by css-extract-rspack-plugin

// EXTERNAL MODULE: ./node_modules/.pnpm/@reduxjs+toolkit@2.9.2_react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1__react@19.2.0/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var redux_toolkit_modern = __webpack_require__(963);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/effects/dist/redux-saga-core-effects.esm.js
var redux_saga_core_effects_esm = __webpack_require__(827);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/dist/redux-saga-core.esm.js
var redux_saga_core_esm = __webpack_require__(287);
// EXTERNAL MODULE: ./node_modules/.pnpm/reselect@5.1.1/node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(526);
;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/app/app.slice.ts

const APP_FEATURE_KEY = 'app';
const initialAppState = {
    page: 'HOME',
    screen: 'COLLECTION'
};
const appSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: APP_FEATURE_KEY,
    initialState: initialAppState,
    reducers: {
        setPage (state, action) {
            return {
                ...state,
                page: action.payload
            };
        },
        setHomepageScreen (state, action) {
            return {
                ...state,
                screen: action.payload.screen
            };
        }
    }
});
const appSliceActions = appSlice.actions;
const appSliceReducer = appSlice.reducer;
const getAppState = (rootState)=>rootState[APP_FEATURE_KEY];
/* Selectors */ const appSliceSelectors = {
    getCurrentPage: (0,reselect/* .createSelector */.Mz)(getAppState, (state)=>state.page),
    getHomepageScreen: (0,reselect/* .createSelector */.Mz)(getAppState, (state)=>state.screen)
};

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-collection-board/history-collection-board.slice.ts

const HISTORY_COLLECTION_BOARD_FEATURE_KEY = 'history-collection-board';
const initialHistortCollectionBoardState = {
    clusters: {}
};
const historyCollectionBoardSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: HISTORY_COLLECTION_BOARD_FEATURE_KEY,
    initialState: initialHistortCollectionBoardState,
    reducers: {
        setBoard (state, action) {
            return {
                ...state,
                clusters: action.payload.clusters
            };
        }
    }
});
const historyCollectionBoardSliceActions = historyCollectionBoardSlice.actions;
const historyCollectionBoardSliceReducer = historyCollectionBoardSlice.reducer;
const getHistoryCollectionBoardState = (rootState)=>rootState[HISTORY_COLLECTION_BOARD_FEATURE_KEY];
/* Selectors */ const historyCollectionBoardSliceSelectors = {
    getBoard: (0,reselect/* .createSelector */.Mz)(getHistoryCollectionBoardState, (state)=>state.clusters)
};

// EXTERNAL MODULE: ./node_modules/.pnpm/lodash@4.17.21/node_modules/lodash/lodash.js
var lodash = __webpack_require__(935);
;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    if (message.name === name) {
                        await callback({
                            sender
                        }, payload);
                    }
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/common/messaging/history-collection-channel/history-collection-channel.ts

function makeHistoryCollectionBoardChannel() {
    return newMessageChannel('HISTORY_COLLECTION_CARD');
}

// EXTERNAL MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
var esm_define_property = __webpack_require__(925);
;// CONCATENATED MODULE: ./src/common/constants/internet-cluster-themes.ts
const internetThemes = [
    {
        id: 1,
        theme: 'Information Seeking',
        icon: 'search',
        colors: {
            primary: '#5C80BC',
            accent: '#A4C6EB',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users search for knowledge such as news updates, tutorials, documentation, or research content to satisfy curiosity or accomplish specific tasks.'
    },
    {
        id: 2,
        theme: 'Entertainment Consumption',
        icon: 'movie',
        colors: {
            primary: '#E57373',
            accent: '#FFB3A7',
            textOnAccent: '#1A1A1A'
        },
        description: 'Includes watching videos, browsing social media, listening to music, reading memes, or playing online games for relaxation and leisure.'
    },
    {
        id: 3,
        theme: 'Shopping and Product Research',
        icon: 'shopping_cart',
        colors: {
            primary: '#81C784',
            accent: '#C8E6C9',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users explore e-commerce sites, compare prices, read product reviews, and look for deals before making purchasing decisions.'
    },
    {
        id: 4,
        theme: 'Social Connection',
        icon: 'chat',
        colors: {
            primary: '#BA68C8',
            accent: '#E1BEE7',
            textOnAccent: '#1A1A1A'
        },
        description: 'Covers engagement on social media platforms, messaging apps, or online communities to stay connected with friends, family, and interest groups.'
    },
    {
        id: 5,
        theme: 'Learning and Skill Development',
        icon: 'school',
        colors: {
            primary: '#FFD54F',
            accent: '#FFF59D',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users visit educational platforms, online courses, or tutorials to build professional skills or learn new topics for personal growth.'
    },
    {
        id: 6,
        theme: 'Productivity and Work-Related Tasks',
        icon: 'work',
        colors: {
            primary: '#90A4AE',
            accent: '#CFD8DC',
            textOnAccent: '#1A1A1A'
        },
        description: 'Involves browsing tools, documentation, and platforms used for collaboration, project management, and professional work.'
    },
    {
        id: 7,
        theme: 'Personal Expression and Creation',
        icon: 'palette',
        colors: {
            primary: '#FFB74D',
            accent: '#FFE0B2',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users express creativity through blogging, digital art, content creation, or sharing personal opinions online.'
    }
];

;// CONCATENATED MODULE: ./src/common/datastore/clustered-webpages-db.ts

// export class ClusteredWebpagesDb {
//   private static instance: ClusteredWebpagesDb;
//   private clusters: Map<string, ClusterDetails> = new Map();
//   private constructor() {}
//   public static getInstance(): ClusteredWebpagesDb {
//     if (!ClusteredWebpagesDb.instance) {
//       ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
//     }
//     return ClusteredWebpagesDb.instance;
//   }
//   public addCluster(clusterDetails: ClusterDetails) {
//     this.clusters.set(clusterDetails.name, clusterDetails);
//   }
//   public getAllClusters(): Array<ClusterDetails> {
//     return Array.from(this.clusters.values());
//   }
// }
class ClusteredWebpagesDb {
    static getInstance() {
        if (!ClusteredWebpagesDb.instance) {
            ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
        }
        return ClusteredWebpagesDb.instance;
    }
    /**
   * Add or update a cluster in chrome.storage.local
   */ async addClusters(clusters) {
        const previousClusters = await this.getAllClustersAsMap();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    async setClusters(clusters) {
        const previousClusters = new Map();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    /**
   * Retrieve all clusters from chrome.storage.local
   */ async getAllClusters() {
        const clusters = await this.getAllClustersAsMap();
        return Array.from(clusters.values());
    }
    /**
   * Internal: Retrieve all clusters as a Map
   */ async getAllClustersAsMap() {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                ClusteredWebpagesDb.STORAGE_KEY
            ], (result)=>{
                const stored = result[ClusteredWebpagesDb.STORAGE_KEY] || {};
                const map = new Map(Object.entries(stored));
                resolve(map);
            });
        });
    }
    /**
   * Internal: Save clusters map back to chrome.storage.local
   */ async saveClustersToStorage(clusters) {
        return new Promise((resolve)=>{
            const obj = Object.fromEntries(clusters);
            chrome.storage.local.set({
                [ClusteredWebpagesDb.STORAGE_KEY]: obj
            }, ()=>resolve());
        });
    }
    constructor(){}
}
(0,esm_define_property._)(ClusteredWebpagesDb, "instance", void 0);
(0,esm_define_property._)(ClusteredWebpagesDb, "STORAGE_KEY", 'clusters');

;// CONCATENATED MODULE: ./src/common/datastore/tab-content-db.ts

class TabContentDb {
    static getInstance() {
        if (!TabContentDb.instance) {
            TabContentDb.instance = new TabContentDb();
        }
        return TabContentDb.instance;
    }
    /** Helper to get data from chrome.storage.local */ async getFromStorage(key) {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                key
            ], (result)=>{
                resolve(result[key]);
            });
        });
    }
    /** Helper to set data in chrome.storage.local */ async setInStorage(key, value) {
        return new Promise((resolve)=>{
            chrome.storage.local.set({
                [key]: value
            }, ()=>resolve());
        });
    }
    /** Add or update tab content details */ async addTabContent(tabContentDetails) {
        const url = tabContentDetails.url;
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        stored[url] = tabContentDetails;
        await this.setInStorage('tabContentProcessed', stored);
    }
    /** Add or update cluster mapping for a URL */ async addClusterToDocument(url, cluster) {
        const stored = await this.getFromStorage('tabCluster') || {};
        stored[url] = cluster;
        await this.setInStorage('tabCluster', stored);
    }
    /** Check if a cluster exists for a given URL */ async hasCluster(url) {
        const stored = await this.getFromStorage('tabCluster') || {};
        return url in stored;
    }
    /** Get all unique content themes */ async getAllThemes() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        const allThemes = Object.values(stored).map((row)=>row.contentThemes).flat();
        // Deduplicate
        return Array.from(new Set(allThemes));
    }
    /** Get all stored tab URLs */ async getAllTabs() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(stored);
    }
    /** Get all tab contents belonging to a specific cluster */ async getAllTabsOfCluster(clusterName) {
        const tabCluster = await this.getFromStorage('tabCluster') || {};
        const tabContentProcessed = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(tabCluster).filter((url)=>tabCluster[url] === clusterName).map((url)=>tabContentProcessed[url]).filter((t)=>!!t);
    }
    /** Get tab content by URL */ async getTabContentByUrl(url) {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return stored[url];
    }
    async unprocessedTabs() {
        const tabs = await this.getAllTabs();
        const stored = await this.getFromStorage('tabCluster') || {};
        const unclusteredTabs = tabs.filter((url)=>!Object.keys(stored).includes(url));
        console.log('unprocess', tabs, stored, unclusteredTabs, Object.keys(stored));
        return unclusteredTabs;
    }
    constructor(){}
}
(0,esm_define_property._)(TabContentDb, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/history-collection-card/history-collection-card.ts




class HistoryCollectionBoard {
    static getInstance() {
        if (!HistoryCollectionBoard.instance) {
            HistoryCollectionBoard.instance = new HistoryCollectionBoard();
        }
        return HistoryCollectionBoard.instance;
    }
    async getHistoryBoard() {
        const clusters = await ClusteredWebpagesDb.getInstance().getAllClusters();
        const historyCollectionCards = await Promise.all(clusters.map(async (cluster)=>{
            const tabs = await TabContentDb.getInstance().getAllTabsOfCluster(cluster.name);
            console.log('History card', {
                clusters,
                tabs
            });
            if (tabs.length > 0) {
                const historyCollectionCard = await this.getHistoryCollectionCard(cluster, tabs);
                return {
                    clusterName: cluster.name,
                    historyCollectionCard
                };
            }
        }));
        const board = historyCollectionCards.filter((t)=>t !== undefined).reduce((acc, param)=>{
            let { clusterName, historyCollectionCard } = param;
            return {
                ...acc,
                [clusterName]: historyCollectionCard
            };
        }, {});
        return board;
    }
    async getHistoryCollectionCard(cluster, webPageDetails) {
        const collectionThemeDetails = internetThemes.find((themeDetails)=>themeDetails.theme === cluster.collectionTheme) || internetThemes["0"];
        const cardTheme = {
            themeIcon: collectionThemeDetails.icon,
            size: 'M',
            primaryColor: collectionThemeDetails.colors.primary,
            accentColor: collectionThemeDetails.colors.accent,
            textColor: collectionThemeDetails.colors.textOnAccent
        };
        const cardTitle = (cluster === null || cluster === void 0 ? void 0 : cluster.cardCaption) || cluster.name;
        // FIXME: populate this properly
        return {
            cardTitle: cardTitle,
            cardDescription: cluster.description,
            theme: cardTheme,
            webPageDetails: webPageDetails.map((param)=>{
                let { url } = param;
                return {
                    domain: new URL(url).hostname,
                    favicon: '',
                    theme: {
                        id: '',
                        name: '',
                        description: ''
                    },
                    navigateUrl: url
                };
            })
        };
    }
    constructor(){}
}
(0,esm_define_property._)(HistoryCollectionBoard, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-collection-board/history-collection-board.saga.ts







const historyCollectionBoardSagaActions = {
    initiateBoardStateUpdate: (0,redux_toolkit_modern/* .createAction */.VP)(`${HISTORY_COLLECTION_BOARD_FEATURE_KEY}/initiateBoardStateUpdate`),
    openCollectionInTabGroup: (0,redux_toolkit_modern/* .createAction */.VP)(`${HISTORY_COLLECTION_BOARD_FEATURE_KEY}/openCollectionInTabGroup`)
};
const historyCollectionBoardSagaWatchers = [
    (0,redux_saga_core_effects_esm/* .takeLatest */.p8)(historyCollectionBoardSagaActions.initiateBoardStateUpdate.type, initiateBoardStateUpdate),
    (0,redux_saga_core_effects_esm/* .takeLatest */.p8)(historyCollectionBoardSagaActions.openCollectionInTabGroup.type, initiateOpenCollectionInTabGroup)
];
function* initiateBoardStateUpdate() {
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(watchHistoryCollectionBoardEvents);
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(loadHistoryCollectionCardsFromStorage);
}
function* initiateOpenCollectionInTabGroup(action) {
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(openAllWebPagesInTabGroup, action.payload.collectionCard);
}
function* loadHistoryCollectionCardsFromStorage() {
    const clusters = yield (0,redux_saga_core_effects_esm/* .call */.T1)(async ()=>{
        return await HistoryCollectionBoard.getInstance().getHistoryBoard();
    });
    console.log('Clusters from extension storage', clusters);
    yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historyCollectionBoardSliceActions.setBoard({
        clusters
    }));
}
function* openAllWebPagesInTabGroup(collectionCard) {
    const cardDetails = yield (0,redux_saga_core_effects_esm/* .call */.T1)(getCardDetailsByCluster, collectionCard);
    if (cardDetails) {
        cardDetails.webPageDetails.map((param)=>{
            let { navigateUrl } = param;
            chrome.tabs.create({
                url: navigateUrl
            });
        });
    }
}
function* getCardDetailsByCluster(cluster) {
    const clusters = yield (0,redux_saga_core_effects_esm/* .select */.Lt)(historyCollectionBoardSliceSelectors.getBoard);
    return lodash._.get(clusters, [
        cluster
    ]);
}
function createHistoryCollectionBoardChannel() {
    return (0,redux_saga_core_esm/* .eventChannel */.Od)((emit)=>{
        const historyCollectionBoardChannel = makeHistoryCollectionBoardChannel();
        historyCollectionBoardChannel.subscribe({}, async (context, messagePayload)=>{
            emit(messagePayload);
        });
        return ()=>{
            historyCollectionBoardChannel.unsubscribe();
        };
    });
}
function* watchHistoryCollectionBoardEvents() {
    const historyCollectionBoardChannel = yield (0,redux_saga_core_effects_esm/* .call */.T1)(createHistoryCollectionBoardChannel);
    while(true){
        const event = yield (0,redux_saga_core_effects_esm/* .take */.s)(historyCollectionBoardChannel);
        console.log({
            event
        });
        yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historyCollectionBoardSliceActions.setBoard({
            clusters: event.clusters
        }));
    }
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-search/history-search.slice.ts

const HISTORY_SEARCH_FEATURE_KEY = 'history-search';
const initialHistortSearchState = {
    query: '',
    searchId: '',
    searchState: '',
    searchResults: []
};
const historySearchSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: HISTORY_SEARCH_FEATURE_KEY,
    initialState: initialHistortSearchState,
    reducers: {
        setQuery (state, action) {
            return {
                ...state,
                query: action.payload.query
            };
        },
        setSearchId (state, action) {
            return {
                ...state,
                SearchId: action.payload.searchId
            };
        },
        setSearchState (state, action) {
            return {
                ...state,
                searchState: action.payload.searchState
            };
        },
        setSearchResults (state, action) {
            return {
                ...state,
                searchResults: action.payload.searchResults
            };
        },
        addSearchResults (state, action) {
            const searchResult = action.payload.searchResult;
            return {
                ...state,
                searchResults: [
                    ...state.searchResults,
                    searchResult
                ]
            };
        },
        resetSearchResults (state, action) {
            return {
                ...state,
                searchResults: []
            };
        }
    }
});
const historySearchSliceActions = historySearchSlice.actions;
const historySearchSliceReducer = historySearchSlice.reducer;
const getHistorySearchState = (rootState)=>rootState[HISTORY_SEARCH_FEATURE_KEY];
/* Selectors */ const historySearchSliceSelectors = {
    getSearchResults: (0,reselect/* .createSelector */.Mz)(getHistorySearchState, (state)=>state.searchResults),
    getSearchState: (0,reselect/* .createSelector */.Mz)(getHistorySearchState, (state)=>state.searchState)
};

;// CONCATENATED MODULE: ./src/common/messaging/history-search-channel/history-search-channel.ts

function makeHistorySearchQueryChannel() {
    return newMessageChannel('HISTORY_SEARCH_QUERY');
}
function makeHistorySearchResultChannel() {
    return newMessageChannel('HISTORY_SEARCH_Result');
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/history-search/history-search.saga.ts






const historySearchSagaActions = {
    searchHistory: (0,redux_toolkit_modern/* .createAction */.VP)(`${HISTORY_SEARCH_FEATURE_KEY}/searchHistory`)
};
const historySearchSagaWatchers = [
    (0,redux_saga_core_effects_esm/* .takeLatest */.p8)(historySearchSagaActions.searchHistory.type, initiateHistorySearch)
];
function* initiateHistorySearch(action) {
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(watchHistorySearchResultEvents);
    yield (0,redux_saga_core_effects_esm/* .fork */.Zy)(sendHistorySearchQueryEvent, action.payload.query);
}
function* sendHistorySearchQueryEvent(query) {
    const searchId = Math.floor(10000 + Math.random() * 90000).toString();
    yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historySearchSliceActions.setSearchId({
        searchId
    }));
    yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historySearchSliceActions.setQuery({
        query
    }));
    yield (0,redux_saga_core_effects_esm/* .put */.yJ)(appSliceActions.setHomepageScreen({
        screen: 'SEARCH_RESULT'
    }));
    yield (0,redux_saga_core_effects_esm/* .call */.T1)(async (query)=>{
        const historySearchQueryEventChannel = makeHistorySearchQueryChannel();
        await historySearchQueryEventChannel.send({}, {
            searchId,
            query
        });
    }, query);
}
function createHistorySearchResultEventChannel() {
    return (0,redux_saga_core_esm/* .eventChannel */.Od)((emit)=>{
        const historySearchResultEventChannel = makeHistorySearchResultChannel();
        historySearchResultEventChannel.subscribe({}, async (context, messagePayload)=>{
            emit(messagePayload);
        });
        return ()=>{
            historySearchResultEventChannel.unsubscribe();
        };
    });
}
function* watchHistorySearchResultEvents() {
    const historySearchResultEventChannel = yield (0,redux_saga_core_effects_esm/* .call */.T1)(createHistorySearchResultEventChannel);
    while(true){
        const event = yield (0,redux_saga_core_effects_esm/* .take */.s)(historySearchResultEventChannel);
        console.log({
            event
        });
        const eventType = event.eventType;
        yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historySearchSliceActions.setSearchState({
            searchState: eventType
        }));
        switch(eventType){
            case 'SEARCH_START':
                yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historySearchSliceActions.resetSearchResults);
                break;
            case 'SEARCH_CLUSTER_RESULT':
                break;
            case 'SEARCH_WEBPAGE_RESULT':
                yield (0,redux_saga_core_effects_esm/* .put */.yJ)(historySearchSliceActions.addSearchResults({
                    searchResult: {
                        navigateUrl: event.navigateUrl,
                        contentSummary: event.contentSummary,
                        score: event.relevanceScore,
                        highlightText: event.highlightText
                    }
                }));
                break;
            case 'SEARCH_FAILED':
                break;
            case 'SEARCH_END':
                break;
            default:
                break;
        }
    // yield put(
    //   historySearchResultSliceActions.setBoard({ clusters: event.clusters }),
    // );
    }
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/middleware/store.ts








const sagaMiddleware = (0,redux_saga_core_esm/* ["default"] */.Ay)();
const store_store = (0,redux_toolkit_modern/* .configureStore */.U1)({
    reducer: {
        [APP_FEATURE_KEY]: appSliceReducer,
        [HISTORY_COLLECTION_BOARD_FEATURE_KEY]: historyCollectionBoardSliceReducer,
        [HISTORY_SEARCH_FEATURE_KEY]: historySearchSliceReducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(sagaMiddleware),
    devTools: true
});
function* rootSaga() {
    yield (0,redux_saga_core_effects_esm/* .all */.Q7)([
        ...historyCollectionBoardSagaWatchers,
        ...historySearchSagaWatchers
    ]);
}
sagaMiddleware.run(rootSaga);
function getStore() {
    return store_store;
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/constants/app-pages.constant.ts

class AppPages {
}
(0,esm_define_property._)(AppPages, "HOME", 'HOME');

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card-icon/card-icons.tsx

function RoundPalette(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M12 2C6.49 2 2 6.49 2 12s4.49 10 10 10a2.5 2.5 0 0 0 2.5-2.5c0-.61-.23-1.2-.64-1.67a.53.53 0 0 1-.13-.33c0-.28.22-.5.5-.5H16c3.31 0 6-2.69 6-6c0-4.96-4.49-9-10-9m5.5 11c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5s1.5.67 1.5 1.5s-.67 1.5-1.5 1.5m-3-4c-.83 0-1.5-.67-1.5-1.5S13.67 6 14.5 6s1.5.67 1.5 1.5S15.33 9 14.5 9M5 11.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5S7.33 13 6.5 13S5 12.33 5 11.5m6-4c0 .83-.67 1.5-1.5 1.5S8 8.33 8 7.5S8.67 6 9.5 6s1.5.67 1.5 1.5"
        })
    });
}
function TwotoneManageSearch(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M2 12h5v2H2zm16.17 1.75c.52-.79.83-1.73.83-2.75c0-2.76-2.24-5-5-5s-5 2.24-5 5s2.24 5 5 5c1.02 0 1.96-.31 2.76-.83L20.59 19L22 17.59zM14 14c-1.65 0-3-1.35-3-3s1.35-3 3-3s3 1.35 3 3s-1.35 3-3 3M2 7h5v2H2zm0 10h10v2H2z"
        })
    });
}
function BaselineMovieFilter(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "m18 4l2 3h-3l-2-3h-2l2 3h-3l-2-3H8l2 3H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4zm-6.75 11.25L10 18l-1.25-2.75L6 14l2.75-1.25L10 10l1.25 2.75L14 14zm5.69-3.31L16 14l-.94-2.06L13 11l2.06-.94L16 8l.94 2.06L19 11z"
        })
    });
}
function BaselineShoppingCart(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2s-.9-2-2-2M1 2v2h2l3.6 7.59l-1.35 2.45c-.16.28-.25.61-.25.96c0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12l.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49A1.003 1.003 0 0 0 20 4H5.21l-.94-2zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2s2-.9 2-2s-.9-2-2-2"
        })
    });
}
function BaselineChat(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2M6 9h12v2H6zm8 5H6v-2h8zm4-6H6V6h12z"
        })
    });
}
function BaselineSchool(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M5 13.18v4L12 21l7-3.82v-4L12 17zM12 3L1 9l11 6l9-4.91V17h2V9z"
        })
    });
}
function BaselineWork(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2m-6 0h-4V4h4z"
        })
    });
}
function BaselineCollectionsBookmark(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "5em",
        height: "5em",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                fill: "currentColor",
                d: "M4 6H2v14c0 1.1.9 2 2 2h14v-2H4z"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
                fill: "currentColor",
                d: "M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2m0 10l-2.5-1.5L15 12V4h5z"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card-icon/history-collection-card-icon.tsx



function HistoryCollectionCardIcon(props) {
    const iconName = props.iconName;
    const iconColor = props.iconColor;
    const defaultIcon = icons['default'];
    const iconComponent = lodash._.get(icons, [
        iconName
    ], defaultIcon);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        style: {
            color: iconColor
        },
        children: iconComponent
    });
}
const icons = {
    search: /*#__PURE__*/ (0,jsx_runtime.jsx)(TwotoneManageSearch, {}),
    movie: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineMovieFilter, {}),
    shopping_cart: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineShoppingCart, {}),
    chat: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineChat, {}),
    school: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineSchool, {}),
    work: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineWork, {}),
    palette: /*#__PURE__*/ (0,jsx_runtime.jsx)(RoundPalette, {}),
    default: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineCollectionsBookmark, {})
};

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-collection-card/history-collection-card.tsx




function HistoryCollectionCardWidget(props) {
    const cardTitle = props.cardDetails.cardTitle;
    const webPageDetails = props.cardDetails.webPageDetails;
    const themeIcon = props.cardDetails.theme.themeIcon;
    const primaryColor = props.cardDetails.theme.primaryColor;
    const accentColor = props.cardDetails.theme.accentColor;
    const textColor = props.cardDetails.theme.textColor;
    const dispatch = (0,react_redux/* .useDispatch */.wA)();
    const links = webPageDetails.reduce((acc, webPage)=>{
        const [_, count] = acc.find((param)=>{
            let [domain, _] = param;
            return domain === webPage.domain;
        }) || [
            webPage.domain,
            0
        ];
        const rest = acc.filter((param)=>{
            let [domain, count] = param;
            return domain !== webPage.domain;
        });
        return [
            ...rest,
            [
                webPage.domain,
                count + 1
            ]
        ];
    }, []).map((param)=>{
        let [domain, count] = param;
        return /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
            className: "text-base text-slate-600",
            children: count > 1 ? `${domain} +${count}` : `${domain}`
        });
    });
    const handleJumpBackIn = (collectionCard)=>{
        dispatch(historyCollectionBoardSagaActions.openCollectionInTabGroup({
            collectionCard
        }));
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full max-w-sm p-6 rounded-2xl font-sans",
        style: {
            backgroundColor: accentColor,
            borderColor: primaryColor,
            color: primaryColor,
            boxShadow: `4px 4px 0px ${primaryColor}`
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex items-center mb-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                        className: "w-12 h-12  mr-4 shrink-0 flex items-center justify-center",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardIcon, {
                            iconName: themeIcon,
                            iconColor: primaryColor
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-3xl font-medium",
                        style: {
                            color: textColor
                        },
                        children: cardTitle
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "pl-12 mb-10",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                    className: "grid grid-cols-1 gap-x-4 gap-y-2",
                    children: links
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                    // className="px-4 py-2 text-sm font-medium text-slate-900 bg-lime-400 border-2 border-lime-600 rounded-lg shadow-[2px_2px_0px_theme(colors.lime.600)] hover:bg-lime-300 active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all"
                    className: "px-4 py-2 text-sm font-medium",
                    style: {
                        color: textColor,
                        backgroundColor: accentColor,
                        borderColor: primaryColor
                    },
                    onClick: ()=>handleJumpBackIn(cardTitle),
                    children: "Jump Back ->"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/histoy-collection-card-board/history-collection-card-board.tsx






function HistoryCollectionCardBoardWidget(props) {
    const dispatch = (0,react_redux/* .useDispatch */.wA)();
    (0,react.useEffect)(()=>{
        dispatch(historyCollectionBoardSagaActions.initiateBoardStateUpdate());
    }, []);
    const historyCardsByCluster = (0,react_redux/* .useSelector */.d4)(historyCollectionBoardSliceSelectors.getBoard);
    console.log({
        historyCardsByCluster
    });
    const cards = Object.entries(historyCardsByCluster).map((param)=>{
        let [cluster, card] = param;
        return /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardWidget, {
            cardDetails: card
        });
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl",
        children: cards
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-search-bar/history-search-bar.tsx




function HistorySearchBar() {
    const dispatch = (0,react_redux/* .useDispatch */.wA)();
    const [searchQuery, setSearchQuery] = (0,react.useState)('');
    const handleSearchQuery = (e)=>{
        setSearchQuery(e.target.value);
    };
    const handleSearchSubmit = ()=>{
        console.log('start search', searchQuery);
        if (searchQuery && searchQuery.length > 0) {
            dispatch(historySearchSagaActions.searchHistory({
                query: searchQuery
            }));
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full max-w-xl mb-12 flex items-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("input", {
                type: "text",
                placeholder: "Describe the thing you are looking for..",
                className: "w-full px-6 py-3 rounded-l-full border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg",
                onChange: handleSearchQuery
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                className: "px-6 py-3 bg-blue-500 text-white font-medium rounded-r-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg",
                onClick: handleSearchSubmit,
                children: "Search"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-search-result-row/history-search-result-row.tsx

function HistorySearchResultRow(props) {
    const title = props.searchResult.navigateUrl;
    const url = props.searchResult.navigateUrl;
    const description = props.searchResult.contentSummary;
    const boldText = props.searchResult.highlightText;
    // highlight the boldText if it exists
    const renderDescription = ()=>{
        if (!boldText || !description.includes(boldText)) return description;
        const [before, after] = description.split(boldText);
        return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [
                before,
                /*#__PURE__*/ (0,jsx_runtime.jsx)("span", {
                    className: "font-semibold text-gray-800 dark:text-gray-100",
                    children: boldText
                }),
                after
            ]
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center justify-between w-full p-4 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-200",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("h2", {
                        className: "text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1",
                        children: title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                        className: "text-sm text-gray-700 dark:text-gray-300",
                        children: renderDescription()
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                onClick: ()=>window.open(url, '_blank'),
                className: "p-2 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors duration-200",
                "aria-label": "Open link",
                children: /*#__PURE__*/ (0,jsx_runtime.jsx)(BaselineArrowOutward, {
                    className: "w-5 h-5 text-blue-600 dark:text-blue-400"
                })
            })
        ]
    });
}
function BaselineArrowOutward(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: "1em",
        height: "1em",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)("path", {
            fill: "currentColor",
            d: "M6 6v2h8.59L5 17.59L6.41 19L16 9.41V18h2V6z"
        })
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/history-search-result/history-search-result.tsx




function HistorySearchResult() {
    const searchResults = (0,react_redux/* .useSelector */.d4)(historySearchSliceSelectors.getSearchResults);
    let searchResultsScored = searchResults;
    if (searchResultsScored.length > 1) searchResultsScored = searchResults.toSorted((resultA, resultB)=>resultB.score - resultA.score);
    const searchState = (0,react_redux/* .useSelector */.d4)(historySearchSliceSelectors.getSearchState);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        children: [
            searchState === 'SEARCH_START' && /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                children: "Searcing in history.."
            }),
            searchState === 'SEARCH_WEBPAGE_RESULT' && /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
                className: "w-full max-w-3xl mx-auto mt-8 bg-white dark:bg-gray-900 rounded-2xl shadow-lg overflow-hidden",
                children: searchResultsScored.map((r, i)=>/*#__PURE__*/ (0,jsx_runtime.jsx)(HistorySearchResultRow, {
                        searchResult: r
                    }, i))
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/home-page/home-page.tsx






function HomePage(props) {
    const screen = (0,react_redux/* .useSelector */.d4)(appSliceSelectors.getHomepageScreen);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "min-h-screen bg-gray-50 flex flex-col items-center py-16 px-6",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                className: "text-5xl font-bold text-gray-800 mb-6 text-center",
                children: "Browse what you have already browsed.."
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)(HistorySearchBar, {}),
            screen === 'COLLECTION' && /*#__PURE__*/ (0,jsx_runtime.jsx)(HistoryCollectionCardBoardWidget, {}),
            screen === 'SEARCH_RESULT' && /*#__PURE__*/ (0,jsx_runtime.jsx)(HistorySearchResult, {})
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/components/page-manager/page-manager.tsx





function PageManagerWidget(props) {
    const currentPage = (0,react_redux/* .useSelector */.d4)(appSliceSelectors.getCurrentPage);
    return /*#__PURE__*/ (0,jsx_runtime.jsx)("div", {
        children: currentPage === AppPages.HOME && /*#__PURE__*/ (0,jsx_runtime.jsx)(HomePage, {})
    });
}

;// CONCATENATED MODULE: ./src/app/search-dashboard-ui/main.tsx







const container = document.getElementById('root');
if (container) {
    const store = getStore();
    const root = (0,client.createRoot)(container);
    root.render(/*#__PURE__*/ (0,jsx_runtime.jsx)(react.StrictMode, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_redux/* .Provider */.Kq, {
            store: store,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(PageManagerWidget, {})
        })
    }));
}


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
id: moduleId,
loaded: false,
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);

// Flag the module as loaded
module.loaded = true;
// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/global
(() => {
__webpack_require__.g = (() => {
	if (typeof globalThis === 'object') return globalThis;
	try {
		return this || new Function('return this')();
	} catch (e) {
		if (typeof window === 'object') return window;
	}
})();
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/node_module_decorator
(() => {
__webpack_require__.nmd = (module) => {
  module.paths = [];
  if (!module.children) module.children = [];
  return module;
};
})();
// webpack/runtime/on_chunk_loaded
(() => {
var deferred = [];
__webpack_require__.O = (result, chunkIds, fn, priority) => {
	if (chunkIds) {
		priority = priority || 0;
		for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
			deferred[i] = deferred[i - 1];
		deferred[i] = [chunkIds, fn, priority];
		return;
	}
	var notFulfilled = Infinity;
	for (var i = 0; i < deferred.length; i++) {
		var [chunkIds, fn, priority] = deferred[i];
		var fulfilled = true;
		for (var j = 0; j < chunkIds.length; j++) {
			if (
				(priority & (1 === 0) || notFulfilled >= priority) &&
				Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))
			) {
				chunkIds.splice(j--, 1);
			} else {
				fulfilled = false;
				if (priority < notFulfilled) notFulfilled = priority;
			}
		}
		if (fulfilled) {
			deferred.splice(i--, 1);
			var r = fn();
			if (r !== undefined) result = r;
		}
	}
	return result;
};

})();
// webpack/runtime/jsonp_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"89": 0,};
      __webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
// install a JSONP callback for chunk loading
var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
	var [chunkIds, moreModules, runtime] = data;
	// add "moreModules" to the modules object,
	// then flag all "chunkIds" as loaded and fire callback
	var moduleId, chunkId, i = 0;
	if (chunkIds.some((id) => (installedChunks[id] !== 0))) {
		for (moduleId in moreModules) {
			if (__webpack_require__.o(moreModules, moduleId)) {
				__webpack_require__.m[moduleId] = moreModules[moduleId];
			}
		}
		if (runtime) var result = runtime(__webpack_require__);
	}
	if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
	for (; i < chunkIds.length; i++) {
		chunkId = chunkIds[i];
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId]
		) {
			installedChunks[chunkId][0]();
		}
		installedChunks[chunkId] = 0;
	}
	return __webpack_require__.O(result);
};

var chunkLoadingGlobal = self["webpackChunkreverie"] = self["webpackChunkreverie"] || [];
chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));

})();
/************************************************************************/
// startup
// Load entry module and return exports
// This entry module depends on other loaded chunks and execution need to be delayed
var __webpack_exports__ = __webpack_require__.O(undefined, ["783", "527", "665"], function() { return __webpack_require__(660) });
__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
})()
;
//# sourceMappingURL=search-dashboard.js.map