(() => { // webpackBootstrap
"use strict";

;// CONCATENATED MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });
    } else obj[key] = value;

    return obj;
}


;// CONCATENATED MODULE: ./src/app/worker/handlers/chrome-ai.handler.ts

class ChromeAIHandler {
    static getInstance() {
        if (!ChromeAIHandler.instance) {
            ChromeAIHandler.instance = new ChromeAIHandler();
        }
        return ChromeAIHandler.instance;
    }
    /**
   * Setup the Web Machine Learning
   */ async setupAI() {
        const availability = await LanguageModel.availability();
        switch(availability){
            case 'available':
                console.log('Language Model is available');
                break;
            case 'unavailable':
                console.log('Language Model is not available');
                break;
            case 'downloadable':
                console.log('Setting things up');
                break;
            case 'downloading':
                console.log('Downloading the model');
                break;
            default:
                break;
        }
    }
    constructor(){}
}
_define_property(ChromeAIHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    await callback({
                        sender
                    }, payload);
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/app/worker/connectors/chrome-extension-connector.ts

class ChromeExtensionConnector {
    static getInstance() {
        if (!ChromeExtensionConnector.instance) {
            ChromeExtensionConnector.instance = new ChromeExtensionConnector();
        }
        return ChromeExtensionConnector.instance;
    }
    async getAllHistory() {
        const millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;
        const oneWeekAgo = new Date().getTime() - millisecondsPerWeek;
        const historyItems = await new Promise((resolve, reject)=>chrome.history.search({
                text: '',
                startTime: oneWeekAgo
            }, (historyItems)=>{
                resolve(historyItems);
            }));
        return historyItems.map((item)=>item === null || item === void 0 ? void 0 : item.url).filter((url)=>url !== undefined);
    }
    async onHistoryUpdate(callback) {
        const visitListener = chrome.history.onVisited.addListener(async (historyItem)=>{
            if (historyItem === null || historyItem === void 0 ? void 0 : historyItem.url) {
                callback({
                    url: historyItem.url
                });
            }
        });
    }
    async injectScriptToTab(scriptPath, tabId) {
        try {
            const result = await chrome.scripting.executeScript({
                target: {
                    tabId
                },
                files: [
                    scriptPath
                ]
            });
            console.log('Script Injection Result', result);
        } catch (err) {
            console.error('Failed to inject script', scriptPath, tabId, err);
        }
    }
    async onTabNavigate(callback) {
        chrome.tabs.onCreated.addListener(async (tab)=>{
            if (tab.id && tab.url) {
                await callback({
                    tabId: tab.id,
                    url: tab.url
                });
            }
        });
        // Inject script when tab is updated (e.g., navigated or reloaded)
        chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab)=>{
            if (changeInfo.status === 'complete' && (tab === null || tab === void 0 ? void 0 : tab.url)) {
                await callback({
                    tabId,
                    url: tab.url
                });
            }
        });
    }
    constructor(){}
}
_define_property(ChromeExtensionConnector, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/handlers/history-collector.handler.ts



class HistoryCollector {
    static getInstance() {
        if (!HistoryCollector.instance) {
            HistoryCollector.instance = new HistoryCollector();
        }
        return HistoryCollector.instance;
    }
    /**
   * Pulls history and syncs for semantic search
   */ async syncHistory() {
        const pipe = ChromeMessagingPipe["new"]({
            name: 'test'
        });
        const urls = await ChromeExtensionConnector.getInstance().getAllHistory();
    // setInterval(() => {
    //   urls.forEach((url) => {
    //     // pipe.publish({ url });
    //     console.log(url);
    //   });
    // }, 2 * 1000);
    }
    async collectHistory() {
        await ChromeExtensionConnector.getInstance().onHistoryUpdate(async (param)=>{
            let { url } = param;
            console.log('visited ', url);
        });
    }
    constructor(){}
}
_define_property(HistoryCollector, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/messaging/tab-summarization-channel/tab-summarization-channel.ts

function makeTabSummarizationChannel() {
    return newMessageChannel('TAB_SUMMARIZATION');
}

;// CONCATENATED MODULE: ./src/app/worker/handlers/tab-content.handler.ts



class TabContentHandler {
    static getInstance() {
        if (!TabContentHandler.instance) {
            TabContentHandler.instance = new TabContentHandler();
        }
        return TabContentHandler.instance;
    }
    async startTabContentReader() {
        // setup listener to capture tab navigation
        //
        console.log('Starting tab content reader');
        await ChromeExtensionConnector.getInstance().onTabNavigate(async (tabDetails)=>{
            const tabId = tabDetails.tabId;
            const url = tabDetails.url;
            if (url && ![
                url.startsWith('chrome://'),
                url.startsWith('chrome-extension://')
            ].some(Boolean)) {
                console.log('Executing grabber on tab', tabId);
                await ChromeExtensionConnector.getInstance().injectScriptToTab('static/js/tab-content-grabber.js', tabId);
            }
        });
        const tabSummarizationMessageChannel = makeTabSummarizationChannel();
        await tabSummarizationMessageChannel.subscribe({}, async (context, payload)=>{
            console.log('Received content', payload);
        // await this.tabContentDb.tabContent.add({
        //   url: payload.url,
        //   contentSummary: payload.contentSummary,
        // });
        });
    // inject content reader script
    }
    constructor(){
    // this.setupTabContentDb();
    }
}
_define_property(TabContentHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/main.ts



console.log('background worker is starting up');
(async ()=>{
    await ChromeAIHandler.getInstance().setupAI();
    await HistoryCollector.getInstance().syncHistory();
    await HistoryCollector.getInstance().collectHistory();
    await TabContentHandler.getInstance().startTabContentReader();
})();

})()
;
//# sourceMappingURL=background.js.map