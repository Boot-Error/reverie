(() => { // webpackBootstrap
"use strict";

;// CONCATENATED MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
function _define_property_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });
    } else obj[key] = value;

    return obj;
}


;// CONCATENATED MODULE: ./src/common/datastore/clustered-webpages-db.ts

// export class ClusteredWebpagesDb {
//   private static instance: ClusteredWebpagesDb;
//   private clusters: Map<string, ClusterDetails> = new Map();
//   private constructor() {}
//   public static getInstance(): ClusteredWebpagesDb {
//     if (!ClusteredWebpagesDb.instance) {
//       ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
//     }
//     return ClusteredWebpagesDb.instance;
//   }
//   public addCluster(clusterDetails: ClusterDetails) {
//     this.clusters.set(clusterDetails.name, clusterDetails);
//   }
//   public getAllClusters(): Array<ClusterDetails> {
//     return Array.from(this.clusters.values());
//   }
// }
class ClusteredWebpagesDb {
    static getInstance() {
        if (!ClusteredWebpagesDb.instance) {
            ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
        }
        return ClusteredWebpagesDb.instance;
    }
    /**
   * Add or update a cluster in chrome.storage.local
   */ async addClusters(clusters) {
        const previousClusters = await this.getAllClustersAsMap();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    async setClusters(clusters) {
        const previousClusters = new Map();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    /**
   * Retrieve all clusters from chrome.storage.local
   */ async getAllClusters() {
        const clusters = await this.getAllClustersAsMap();
        return Array.from(clusters.values());
    }
    /**
   * Internal: Retrieve all clusters as a Map
   */ async getAllClustersAsMap() {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                ClusteredWebpagesDb.STORAGE_KEY
            ], (result)=>{
                const stored = result[ClusteredWebpagesDb.STORAGE_KEY] || {};
                const map = new Map(Object.entries(stored));
                resolve(map);
            });
        });
    }
    /**
   * Internal: Save clusters map back to chrome.storage.local
   */ async saveClustersToStorage(clusters) {
        return new Promise((resolve)=>{
            const obj = Object.fromEntries(clusters);
            chrome.storage.local.set({
                [ClusteredWebpagesDb.STORAGE_KEY]: obj
            }, ()=>resolve());
        });
    }
    constructor(){}
}
_define_property_define_property(ClusteredWebpagesDb, "instance", void 0);
_define_property_define_property(ClusteredWebpagesDb, "STORAGE_KEY", 'clusters');

;// CONCATENATED MODULE: ./src/common/datastore/tab-content-db.ts

class TabContentDb {
    static getInstance() {
        if (!TabContentDb.instance) {
            TabContentDb.instance = new TabContentDb();
        }
        return TabContentDb.instance;
    }
    /** Helper to get data from chrome.storage.local */ async getFromStorage(key) {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                key
            ], (result)=>{
                resolve(result[key]);
            });
        });
    }
    /** Helper to set data in chrome.storage.local */ async setInStorage(key, value) {
        return new Promise((resolve)=>{
            chrome.storage.local.set({
                [key]: value
            }, ()=>resolve());
        });
    }
    /** Add or update tab content details */ async addTabContent(tabContentDetails) {
        const url = tabContentDetails.url;
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        stored[url] = tabContentDetails;
        await this.setInStorage('tabContentProcessed', stored);
    }
    /** Add or update cluster mapping for a URL */ async addClusterToDocument(url, cluster) {
        const stored = await this.getFromStorage('tabCluster') || {};
        stored[url] = cluster;
        await this.setInStorage('tabCluster', stored);
    }
    /** Check if a cluster exists for a given URL */ async hasCluster(url) {
        const stored = await this.getFromStorage('tabCluster') || {};
        return url in stored;
    }
    /** Get all unique content themes */ async getAllThemes() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        const allThemes = Object.values(stored).map((row)=>row.contentThemes).flat();
        // Deduplicate
        return Array.from(new Set(allThemes));
    }
    /** Get all stored tab URLs */ async getAllTabs() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(stored);
    }
    /** Get all tab contents belonging to a specific cluster */ async getAllTabsOfCluster(clusterName) {
        const tabCluster = await this.getFromStorage('tabCluster') || {};
        const tabContentProcessed = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(tabCluster).filter((url)=>tabCluster[url] === clusterName).map((url)=>tabContentProcessed[url]).filter((t)=>!!t);
    }
    /** Get tab content by URL */ async getTabContentByUrl(url) {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return stored[url];
    }
    async unprocessedTabs() {
        const tabs = await this.getAllTabs();
        const stored = await this.getFromStorage('tabCluster') || {};
        const unclusteredTabs = tabs.filter((url)=>!Object.keys(stored).includes(url));
        console.log('unprocess', tabs, stored, unclusteredTabs, Object.keys(stored));
        return unclusteredTabs;
    }
    constructor(){}
}
_define_property_define_property(TabContentDb, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/llm-functions/utils.ts
async function checkAvailability() {
    const availability = await LanguageModel.availability();
    if (availability !== 'available') {
        console.error('Unable to extract themes from the content due to ', availability);
    }
    return availability === 'available';
}
async function createPromptSession() {
    const session = await LanguageModel.create({
        monitor (m) {
            m.addEventListener('downloadprogress', (e)=>{
                console.log(`Downloaded ${e.loaded * 100}%`);
            });
        }
    });
    return session;
}

;// CONCATENATED MODULE: ./src/common/llm-functions/query-cluster-scoring.ts

const clusterQueryScoringSchema = {
    type: 'array',
    items: {
        type: 'object',
        properties: {
            clusterName: {
                type: 'string'
            },
            score: {
                type: 'number'
            }
        }
    }
};
async function scoreQueryWithClusters(query, clusters) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    const clusterAndDescription = clusters.map((param)=>{
        let { name, description } = param;
        return JSON.stringify({
            clusterName: name,
            clusterDescription: description
        });
    });
    const queryClusterScorePrompt = `From the list of clusters:

    ${clusterAndDescription}

    And this search query:
    ${query}

    Score each of the cluster between 1 to 10 based on how close the content will be in that cluster`;
    const result = await session.prompt(queryClusterScorePrompt, {
        responseConstraint: clusterQueryScoringSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('score', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/llm-functions/query-tab-summary-scoring.ts

const tabSummaryQueryScoringSchema = {
    type: 'object',
    properties: {
        score: {
            type: 'number'
        },
        highlightText: {
            type: 'string'
        }
    }
};
async function scoreQueryWithTabSummary(query, tabContentSummary) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const querySummaryScoringPrompt = `You will act as an expert information retrieval and semantic matching system. Your task is to evaluate how relevant a given summary is to a search query. Analyze the meaning, not just keyword overlap, to produce a detailed and reasoned response.

  For each input pair (summary, search query):

  1. Provide a relevance score between 0 and 1, where:
    0 = completely irrelevant
    0.5 = partially related or tangentially relevant
    1 = highly relevant and directly addressing the query

  2. Identify and return the most relevant part of the summary text that best supports the match.

  Ensure your assessment accounts for semantic similarity, contextual meaning, and intent alignment between the query and the summary.

  The Search Query: ${query}
  The Content Summary: ${tabContentSummary}
  `;
    const session = await createPromptSession();
    const result = await session.prompt(querySummaryScoringPrompt, {
        responseConstraint: tabSummaryQueryScoringSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('summary score', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    if (message.name === name) {
                        await callback({
                            sender
                        }, payload);
                    }
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/common/messaging/history-search-channel/history-search-channel.ts

function makeHistorySearchQueryChannel() {
    return newMessageChannel('HISTORY_SEARCH_QUERY');
}
function makeHistorySearchResultChannel() {
    return newMessageChannel('HISTORY_SEARCH_Result');
}

;// CONCATENATED MODULE: ./src/common/history-search/history-search.handler.ts






class HistorySearchHandler {
    static getInstance() {
        if (!HistorySearchHandler.instance) {
            HistorySearchHandler.instance = new HistorySearchHandler();
        }
        return HistorySearchHandler.instance;
    }
    async setupHistorySearchQueryListener() {
        const historySearchQueryEventChannel = makeHistorySearchQueryChannel();
        await historySearchQueryEventChannel.subscribe({}, async (context, message)=>{
            const searchQuery = message.query;
            const searchId = message.searchId;
            console.log('Got search Request', message);
            await this.searchInHistory(searchId, searchQuery);
        });
    }
    async searchInHistory(searchId, query) {
        // match query with most relevant cluster
        const allClusters = await ClusteredWebpagesDb.getInstance().getAllClusters();
        this.historySearchResultEventChannel.send({}, {
            eventType: 'SEARCH_START',
            searchId
        });
        const queryClusterScores = await scoreQueryWithClusters(query, allClusters);
        const scoringCluster = queryClusterScores.reduce((acc, current)=>{
            return current.score >= acc.score ? current : acc;
        }, {
            clusterName: '',
            score: 0
        });
        this.historySearchResultEventChannel.send({}, {
            eventType: 'SEARCH_CLUSTER_RESULT',
            searchId,
            scoringCluster: scoringCluster.clusterName
        });
        const webPages = await TabContentDb.getInstance().getAllTabsOfCluster(scoringCluster.clusterName);
        await Promise.all(webPages.map(async (tab)=>{
            const result = await scoreQueryWithTabSummary(query, tab.contentSummary);
            this.historySearchResultEventChannel.send({}, {
                eventType: 'SEARCH_WEBPAGE_RESULT',
                searchId,
                navigateUrl: tab.url,
                contentSummary: tab.contentSummary,
                relevanceScore: result.score,
                highlightText: result.highlightText
            });
        }));
    }
    constructor(){
        _define_property_define_property(this, "historySearchResultEventChannel", void 0);
        this.historySearchResultEventChannel = makeHistorySearchResultChannel();
    }
}
_define_property_define_property(HistorySearchHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/messaging/tab-summarization-channel/tab-summarization-channel.ts

function makeTabSummarizationChannel() {
    return newMessageChannel('TAB_SUMMARIZATION');
}

;// CONCATENATED MODULE: ./src/app/worker/connectors/chrome-extension-connector.ts

class ChromeExtensionConnector {
    static getInstance() {
        if (!ChromeExtensionConnector.instance) {
            ChromeExtensionConnector.instance = new ChromeExtensionConnector();
        }
        return ChromeExtensionConnector.instance;
    }
    async getAllHistory() {
        const millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;
        const oneWeekAgo = new Date().getTime() - millisecondsPerWeek;
        const historyItems = await new Promise((resolve, reject)=>chrome.history.search({
                text: '',
                startTime: oneWeekAgo
            }, (historyItems)=>{
                resolve(historyItems);
            }));
        return historyItems.map((item)=>item === null || item === void 0 ? void 0 : item.url).filter((url)=>url !== undefined);
    }
    async onHistoryUpdate(callback) {
        const visitListener = chrome.history.onVisited.addListener(async (historyItem)=>{
            if (historyItem === null || historyItem === void 0 ? void 0 : historyItem.url) {
                callback({
                    url: historyItem.url
                });
            }
        });
    }
    async injectScriptToTab(scriptPath, tabId) {
        try {
            const result = await chrome.scripting.executeScript({
                target: {
                    tabId
                },
                files: [
                    scriptPath
                ]
            });
            console.log('Script Injection Result', result);
        } catch (err) {
            console.error('Failed to inject script', scriptPath, tabId, err);
        }
    }
    async onTabNavigate(callback) {
        chrome.tabs.onCreated.addListener(async (tab)=>{
            if (tab.id && tab.url) {
                await callback({
                    tabId: tab.id,
                    url: tab.url
                });
            }
        });
        // Inject script when tab is updated (e.g., navigated or reloaded)
        chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab)=>{
            if (changeInfo.status === 'complete' && (tab === null || tab === void 0 ? void 0 : tab.url)) {
                await callback({
                    tabId,
                    url: tab.url
                });
            }
        });
    }
    constructor(){}
}
_define_property_define_property(ChromeExtensionConnector, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/llm-functions/determine-cluster.ts

const clusterSchema = {
    type: 'array',
    items: {
        type: 'object',
        properties: {
            name: {
                type: 'string'
            },
            themes: {
                type: 'array',
                items: {
                    type: 'string'
                }
            },
            description: {
                type: 'string'
            }
        }
    }
};
async function determineThematicClustering(themes) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const uniqueThemes = themes.reduce((acc, theme)=>{
        return acc.includes(theme) ? acc : [
            ...acc,
            theme
        ];
    }, []);
    const session = await createPromptSession();
    const clusteringPrompt = `Here is a list of themes extracted from multiple documents:
      ${JSON.stringify(uniqueThemes)}

    Group these themes into coherent thematic clusters.
    Each cluster should have:
    1. A cluster name (3-5 words)
    2. Member themes (list)
    3. One-sentence cluster description
    `;
    const result = await session.prompt(clusteringPrompt, {
        responseConstraint: clusterSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('Clusters', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/llm-functions/document-cluster-selection.ts

const document_cluster_selection_clusterSchema = {
    type: 'object',
    properties: {
        assignedCluster: {
            type: 'string'
        },
        confidence: {
            type: 'number'
        }
    }
};
async function findClusterForDocument(contentSummary, clusters) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    // const clustersAsPoints = clusters.reduce((acc, cluster, index) => {
    //   return `${acc}\n${index}. ${cluster}`;
    // }, '');
    const clusterDocumentMatchingPrompt = `Given the following thematic clusters:
    ${clusters}

  And this document:
  "${contentSummary}

  Assign the document to the most relevant thematic cluster by reasoning about the main topic.
`;
    const result = await session.prompt(clusterDocumentMatchingPrompt, {
        responseConstraint: document_cluster_selection_clusterSchema
    });
    console.log('Relevant cluster', result, contentSummary);
    const parsedResult = JSON.parse(result);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/messaging/history-collection-channel/history-collection-channel.ts

function makeHistoryCollectionBoardChannel() {
    return newMessageChannel('HISTORY_COLLECTION_CARD');
}

;// CONCATENATED MODULE: ./src/common/constants/internet-cluster-themes.ts
const internetThemes = [
    {
        id: 1,
        theme: 'Information Seeking',
        icon: 'search',
        colors: {
            primary: '#5C80BC',
            accent: '#A4C6EB',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users search for knowledge such as news updates, tutorials, documentation, or research content to satisfy curiosity or accomplish specific tasks.'
    },
    {
        id: 2,
        theme: 'Entertainment Consumption',
        icon: 'movie',
        colors: {
            primary: '#E57373',
            accent: '#FFB3A7',
            textOnAccent: '#1A1A1A'
        },
        description: 'Includes watching videos, browsing social media, listening to music, reading memes, or playing online games for relaxation and leisure.'
    },
    {
        id: 3,
        theme: 'Shopping and Product Research',
        icon: 'shopping_cart',
        colors: {
            primary: '#81C784',
            accent: '#C8E6C9',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users explore e-commerce sites, compare prices, read product reviews, and look for deals before making purchasing decisions.'
    },
    {
        id: 4,
        theme: 'Social Connection',
        icon: 'chat',
        colors: {
            primary: '#BA68C8',
            accent: '#E1BEE7',
            textOnAccent: '#1A1A1A'
        },
        description: 'Covers engagement on social media platforms, messaging apps, or online communities to stay connected with friends, family, and interest groups.'
    },
    {
        id: 5,
        theme: 'Learning and Skill Development',
        icon: 'school',
        colors: {
            primary: '#FFD54F',
            accent: '#FFF59D',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users visit educational platforms, online courses, or tutorials to build professional skills or learn new topics for personal growth.'
    },
    {
        id: 6,
        theme: 'Productivity and Work-Related Tasks',
        icon: 'work',
        colors: {
            primary: '#90A4AE',
            accent: '#CFD8DC',
            textOnAccent: '#1A1A1A'
        },
        description: 'Involves browsing tools, documentation, and platforms used for collaboration, project management, and professional work.'
    },
    {
        id: 7,
        theme: 'Personal Expression and Creation',
        icon: 'palette',
        colors: {
            primary: '#FFB74D',
            accent: '#FFE0B2',
            textOnAccent: '#1A1A1A'
        },
        description: 'Users express creativity through blogging, digital art, content creation, or sharing personal opinions online.'
    }
];

;// CONCATENATED MODULE: ./src/common/history-collection-card/history-collection-card.ts




class HistoryCollectionBoard {
    static getInstance() {
        if (!HistoryCollectionBoard.instance) {
            HistoryCollectionBoard.instance = new HistoryCollectionBoard();
        }
        return HistoryCollectionBoard.instance;
    }
    async getHistoryBoard() {
        const clusters = await ClusteredWebpagesDb.getInstance().getAllClusters();
        const historyCollectionCards = await Promise.all(clusters.map(async (cluster)=>{
            const tabs = await TabContentDb.getInstance().getAllTabsOfCluster(cluster.name);
            console.log('History card', {
                clusters,
                tabs
            });
            if (tabs.length > 0) {
                const historyCollectionCard = await this.getHistoryCollectionCard(cluster, tabs);
                return {
                    clusterName: cluster.name,
                    historyCollectionCard
                };
            }
        }));
        const board = historyCollectionCards.filter((t)=>t !== undefined).reduce((acc, param)=>{
            let { clusterName, historyCollectionCard } = param;
            return {
                ...acc,
                [clusterName]: historyCollectionCard
            };
        }, {});
        return board;
    }
    async getHistoryCollectionCard(cluster, webPageDetails) {
        const collectionThemeDetails = internetThemes.find((themeDetails)=>themeDetails.theme === cluster.collectionTheme) || internetThemes["0"];
        const cardTheme = {
            themeIcon: collectionThemeDetails.icon,
            size: 'M',
            primaryColor: collectionThemeDetails.colors.primary,
            accentColor: collectionThemeDetails.colors.accent,
            textColor: collectionThemeDetails.colors.textOnAccent
        };
        const cardTitle = (cluster === null || cluster === void 0 ? void 0 : cluster.cardCaption) || cluster.name;
        // FIXME: populate this properly
        return {
            cardTitle: cardTitle,
            cardDescription: cluster.description,
            theme: cardTheme,
            webPageDetails: webPageDetails.map((param)=>{
                let { url } = param;
                return {
                    domain: new URL(url).hostname,
                    favicon: '',
                    theme: {
                        id: '',
                        name: '',
                        description: ''
                    },
                    navigateUrl: url
                };
            })
        };
    }
    constructor(){}
}
_define_property_define_property(HistoryCollectionBoard, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/llm-functions/determine-cluster-theme.ts


const clusterThemeSchema = {
    type: 'object',
    properties: {
        theme: {
            type: 'string'
        },
        confidence: {
            type: 'string'
        }
    }
};
async function determineClusterTheme(clusterDetails) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    const clusterThemePrompt = `Given the following list of themes common to webpages on internet:
      ${JSON.stringify(internetThemes)}


      And this cluster:
      "${JSON.stringify(clusterDetails)}

      Assign the cluster to the most related theme by reasoning on the coherence between the theme description and cluster description.
    `;
    const result = await session.prompt(clusterThemePrompt, {
        responseConstraint: clusterThemeSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('Cluster Theme', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/llm-functions/cluster-card-caption.ts

const clusterCaptionSchema = {
    type: 'object',
    properties: {
        caption: {
            type: 'string'
        }
    }
};
async function getClusterCaption(clusterDetails) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    const clusterCaptionPrompt = `
    From the following text:
    "${clusterDetails.description}"

    Create a actionable caption with 4-8 words
    `;
    const result = await session.prompt(clusterCaptionPrompt, {
        responseConstraint: clusterCaptionSchema
    });
    const parsedResult = JSON.parse(result);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/app/worker/handlers/dashboard-handler.ts









class DashboardHandler {
    static getInstance() {
        if (!DashboardHandler.instance) {
            DashboardHandler.instance = new DashboardHandler();
        }
        return DashboardHandler.instance;
    }
    async updateThematicClusters() {
        const themes = await TabContentDb.getInstance().getAllThemes();
        // generate new clusters
        const clusters = await determineThematicClustering(themes);
        const updatedClustersWithTheme = await Promise.all(clusters.map(async (clusterDetails)=>{
            const clusterCollectionTheme = await determineClusterTheme(clusterDetails);
            const clusterCaption = await getClusterCaption(clusterDetails);
            return {
                ...clusterDetails,
                collectionTheme: clusterCollectionTheme.theme,
                cardCaption: clusterCaption.caption
            };
        }));
        await ClusteredWebpagesDb.getInstance().setClusters(updatedClustersWithTheme);
        console.log('Clusters', clusters);
        const allTabs = await TabContentDb.getInstance().getAllTabs();
        await Promise.all(allTabs.map(async (url)=>{
            const tabDetails = await TabContentDb.getInstance().getTabContentByUrl(url);
            if (tabDetails) {
                const clusterNames = (await ClusteredWebpagesDb.getInstance().getAllClusters()).map((clusterDetails)=>clusterDetails.name);
                const documentCluster = await findClusterForDocument(tabDetails.contentSummary, clusterNames);
                await TabContentDb.getInstance().addClusterToDocument(tabDetails.url, documentCluster.assignedCluster);
            }
        }));
        this.publishBoardUpdates();
    }
    async publishBoardUpdates() {
        const historyCollectionBoard = await HistoryCollectionBoard.getInstance().getHistoryBoard();
        // FIXME: sometimes it returns undefined, find the root cause of it
        if (HistoryCollectionBoard) {
            await this.historyCollectionBoardChannel.send({}, {
                clusters: historyCollectionBoard
            });
        }
    }
    constructor(){
        _define_property_define_property(this, "historyCollectionBoardChannel", void 0);
        this.historyCollectionBoardChannel = makeHistoryCollectionBoardChannel();
    }
}
_define_property_define_property(DashboardHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/handlers/tab-content.handler.ts







class TabContentHandler {
    static getInstance() {
        if (!TabContentHandler.instance) {
            TabContentHandler.instance = new TabContentHandler();
        }
        return TabContentHandler.instance;
    }
    async startTabContentReader() {
        // setup listener to capture tab navigation
        //
        console.log('Starting tab content reader');
        console.log('Start Tab content script injector');
        await ChromeExtensionConnector.getInstance().onTabNavigate(async (tabDetails)=>{
            const tabId = tabDetails.tabId;
            const url = tabDetails.url;
            if (!url) {
                return;
            }
            /**
         * Check and process if the tab is seen first time
         */ const tabAlreadyProcessed = await TabContentDb.getInstance().getTabContentByUrl(url);
            if (![
                url.startsWith('chrome://'),
                url.startsWith('chrome-extension://')
            ].some(Boolean) && !tabAlreadyProcessed) {
                console.log('Executing grabber on tab', tabId);
                await ChromeExtensionConnector.getInstance().injectScriptToTab('static/js/tab-content-grabber.js', tabId);
            }
        });
        const tabSummarizationMessageChannel = makeTabSummarizationChannel();
        console.log('Start Tab content capture channel');
        await tabSummarizationMessageChannel.subscribe({}, async (context, payload)=>{
            console.log('Received content', payload);
            await TabContentDb.getInstance().addTabContent({
                ...payload
            });
            const clusterNames = (await ClusteredWebpagesDb.getInstance().getAllClusters()).map((clusterDetails)=>clusterDetails.name);
            /**
         * Find an existing cluster, if not found then buffer it for processing
         */ if (clusterNames.length > 2) {
                console.log('finding cluster');
                const documentCluster = await findClusterForDocument(payload.contentSummary, clusterNames);
                console.log({
                    documentCluster
                });
                if (documentCluster.confidence > 0.9) {
                    await TabContentDb.getInstance().addClusterToDocument(payload.url, documentCluster.assignedCluster);
                    await DashboardHandler.getInstance().publishBoardUpdates();
                } else {
                    console.log('Low ranking document, not added to a cluster');
                    this.lowRankingTabsCapturedTotal += 1;
                }
            } else {
                // since no clusters, there is nothing to rank with
                this.lowRankingTabsCapturedTotal += 1;
            }
            await this.bufferedClustering();
        });
        // process unprocessed tabs
        console.log('Check for unprocessed tabs');
        const unprocessedTabs = await TabContentDb.getInstance().unprocessedTabs();
        console.log(unprocessedTabs, unprocessedTabs.length);
        if (unprocessedTabs.length > 5) {
            console.log('Processing unprocessed tab with thematic update', {
                tabs: unprocessedTabs.length
            });
            await DashboardHandler.getInstance().updateThematicClusters();
        }
    }
    async bufferedClustering() {
        if (this.lowRankingTabsCapturedTotal > 3) {
            console.log('Starting thematic clustering updated');
            this.lowRankingTabsCapturedTotal = 0;
            await DashboardHandler.getInstance().updateThematicClusters();
        }
    }
    constructor(){
        _define_property_define_property(this, "lowRankingTabsCapturedTotal", void 0);
        this.lowRankingTabsCapturedTotal = 0;
    }
}
_define_property_define_property(TabContentHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/main.ts


console.log('background worker is starting up');
(async ()=>{
    // await ChromeAIHandler.getInstance().setupAI();
    // await HistoryCollector.getInstance().syncHistory();
    // await HistoryCollector.getInstance().collectHistory();
    await TabContentHandler.getInstance().startTabContentReader();
    await HistorySearchHandler.getInstance().setupHistorySearchQueryListener();
})();

})()
;
//# sourceMappingURL=background.js.map