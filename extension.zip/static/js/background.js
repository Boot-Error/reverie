(() => { // webpackBootstrap
"use strict";

;// CONCATENATED MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
function _define_property_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });
    } else obj[key] = value;

    return obj;
}


;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    if (message.name === name) {
                        await callback({
                            sender
                        }, payload);
                    }
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/common/messaging/tab-summarization-channel/tab-summarization-channel.ts

function makeTabSummarizationChannel() {
    return newMessageChannel('TAB_SUMMARIZATION');
}

;// CONCATENATED MODULE: ./src/app/worker/connectors/chrome-extension-connector.ts

class ChromeExtensionConnector {
    static getInstance() {
        if (!ChromeExtensionConnector.instance) {
            ChromeExtensionConnector.instance = new ChromeExtensionConnector();
        }
        return ChromeExtensionConnector.instance;
    }
    async getAllHistory() {
        const millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;
        const oneWeekAgo = new Date().getTime() - millisecondsPerWeek;
        const historyItems = await new Promise((resolve, reject)=>chrome.history.search({
                text: '',
                startTime: oneWeekAgo
            }, (historyItems)=>{
                resolve(historyItems);
            }));
        return historyItems.map((item)=>item === null || item === void 0 ? void 0 : item.url).filter((url)=>url !== undefined);
    }
    async onHistoryUpdate(callback) {
        const visitListener = chrome.history.onVisited.addListener(async (historyItem)=>{
            if (historyItem === null || historyItem === void 0 ? void 0 : historyItem.url) {
                callback({
                    url: historyItem.url
                });
            }
        });
    }
    async injectScriptToTab(scriptPath, tabId) {
        try {
            const result = await chrome.scripting.executeScript({
                target: {
                    tabId
                },
                files: [
                    scriptPath
                ]
            });
            console.log('Script Injection Result', result);
        } catch (err) {
            console.error('Failed to inject script', scriptPath, tabId, err);
        }
    }
    async onTabNavigate(callback) {
        chrome.tabs.onCreated.addListener(async (tab)=>{
            if (tab.id && tab.url) {
                await callback({
                    tabId: tab.id,
                    url: tab.url
                });
            }
        });
        // Inject script when tab is updated (e.g., navigated or reloaded)
        chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab)=>{
            if (changeInfo.status === 'complete' && (tab === null || tab === void 0 ? void 0 : tab.url)) {
                await callback({
                    tabId,
                    url: tab.url
                });
            }
        });
    }
    constructor(){}
}
_define_property_define_property(ChromeExtensionConnector, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/datastore/tab-content-db.ts

// export class TabContentDb {
//   private static instance: TabContentDb;
//   // private db: IDBDatabase;
//   private tabContentProcessed: Map<string, TabContentProcessedDetails> =
//     new Map();
//   private tabCluster: Map<string, string> = new Map();
//   private constructor() {
//     // (async () => {
//     //   await this.setupDb();
//     // })();
//   }
//   public static getInstance(): TabContentDb {
//     if (!TabContentDb.instance) {
//       TabContentDb.instance = new TabContentDb();
//     }
//     return TabContentDb.instance;
//   }
//   public async addTabContent(tabContentDetails: TabContentProcessedDetails) {
//     const url = tabContentDetails.url;
//     this.tabContentProcessed.set(url, tabContentDetails);
//     // const db = await this.getDb();
//     // const transaction = db.transaction('tab-content-processed', 'readwrite');
//     // const row = transaction.objectStore('tab-content-processed');
//     // const request = row.add(tabContentDetails);
//     // request.onsuccess = async () => {
//     //   console.log('tab added');
//     // };
//     // request.onerror = async () => {
//     //   console.error('Error adding tab', request.error);
//     // };
//   }
//   public addClusterToDocument(url: string, cluster: string) {
//     this.tabCluster.set(url, cluster);
//     chrome.storage.local.set()
//   }
//   public hasCluster(url: string) {
//     return this.tabCluster.has(url);
//   }
//   public getAllThemes(): Array<string> {
//     return Array.from(this.tabContentProcessed.values())
//       .map((row: TabContentProcessedDetails) => row.contentThemes)
//       .reduce((acc, themes) => {
//         return [...acc, ...themes.filter((theme) => !acc.includes(theme))];
//       }, []);
//   }
//   public getAllTabs() {
//     return Array.from(this.tabContentProcessed.keys());
//   }
//   public getAllTabsOfCluster(
//     clusterName: string,
//   ): Array<TabContentProcessedDetails> {
//     return Array.from(this.tabCluster.keys())
//       .filter((url) => this.tabCluster.get(url) === clusterName)
//       .map((url) => this.tabContentProcessed.get(url))
//       .filter((t) => t !== undefined);
//   }
//   public getTabContentByUrl(
//     url: string,
//   ): TabContentProcessedDetails | undefined {
//     return this.tabContentProcessed.get(url);
//   }
// }
class TabContentDb {
    static getInstance() {
        if (!TabContentDb.instance) {
            TabContentDb.instance = new TabContentDb();
        }
        return TabContentDb.instance;
    }
    /** Helper to get data from chrome.storage.local */ async getFromStorage(key) {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                key
            ], (result)=>{
                resolve(result[key]);
            });
        });
    }
    /** Helper to set data in chrome.storage.local */ async setInStorage(key, value) {
        return new Promise((resolve)=>{
            chrome.storage.local.set({
                [key]: value
            }, ()=>resolve());
        });
    }
    /** Add or update tab content details */ async addTabContent(tabContentDetails) {
        const url = tabContentDetails.url;
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        stored[url] = tabContentDetails;
        await this.setInStorage('tabContentProcessed', stored);
    }
    /** Add or update cluster mapping for a URL */ async addClusterToDocument(url, cluster) {
        const stored = await this.getFromStorage('tabCluster') || {};
        stored[url] = cluster;
        await this.setInStorage('tabCluster', stored);
    }
    /** Check if a cluster exists for a given URL */ async hasCluster(url) {
        const stored = await this.getFromStorage('tabCluster') || {};
        return stored.hasOwnProperty(url);
    }
    /** Get all unique content themes */ async getAllThemes() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        const allThemes = Object.values(stored).map((row)=>row.contentThemes).flat();
        // Deduplicate
        return Array.from(new Set(allThemes));
    }
    /** Get all stored tab URLs */ async getAllTabs() {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(stored);
    }
    /** Get all tab contents belonging to a specific cluster */ async getAllTabsOfCluster(clusterName) {
        const tabCluster = await this.getFromStorage('tabCluster') || {};
        const tabContentProcessed = await this.getFromStorage('tabContentProcessed') || {};
        return Object.keys(tabCluster).filter((url)=>tabCluster[url] === clusterName).map((url)=>tabContentProcessed[url]).filter((t)=>!!t);
    }
    /** Get tab content by URL */ async getTabContentByUrl(url) {
        const stored = await this.getFromStorage('tabContentProcessed') || {};
        return stored[url];
    }
    constructor(){}
}
_define_property_define_property(TabContentDb, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/llm-functions/utils.ts
async function checkAvailability() {
    const availability = await LanguageModel.availability();
    if (availability !== 'available') {
        console.error('Unable to extract themes from the content due to ', availability);
    }
    return availability === 'available';
}
async function createPromptSession() {
    const session = await LanguageModel.create({
        monitor (m) {
            m.addEventListener('downloadprogress', (e)=>{
                console.log(`Downloaded ${e.loaded * 100}%`);
            });
        }
    });
    return session;
}

;// CONCATENATED MODULE: ./src/common/llm-functions/determine-cluster.ts

const clusterSchema = {
    type: 'array',
    items: {
        type: 'object',
        properties: {
            name: {
                type: 'string'
            },
            themes: {
                type: 'array',
                items: {
                    type: 'string'
                }
            },
            description: {
                type: 'string'
            }
        }
    }
};
async function determineThematicClustering(themes) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    const clusteringPrompt = `Here is a list of themes extracted from multiple documents:
      ${JSON.stringify(themes)}

    Group these themes into coherent thematic clusters.
    Each cluster should have:
    1. A cluster name (3-5 words)
    2. Member themes (list)
    3. One-sentence cluster description
    `;
    const result = await session.prompt(clusteringPrompt, {
        responseConstraint: clusterSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('Clusters', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/datastore/clustered-webpages-db.ts

// export class ClusteredWebpagesDb {
//   private static instance: ClusteredWebpagesDb;
//   private clusters: Map<string, ClusterDetails> = new Map();
//   private constructor() {}
//   public static getInstance(): ClusteredWebpagesDb {
//     if (!ClusteredWebpagesDb.instance) {
//       ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
//     }
//     return ClusteredWebpagesDb.instance;
//   }
//   public addCluster(clusterDetails: ClusterDetails) {
//     this.clusters.set(clusterDetails.name, clusterDetails);
//   }
//   public getAllClusters(): Array<ClusterDetails> {
//     return Array.from(this.clusters.values());
//   }
// }
class ClusteredWebpagesDb {
    static getInstance() {
        if (!ClusteredWebpagesDb.instance) {
            ClusteredWebpagesDb.instance = new ClusteredWebpagesDb();
        }
        return ClusteredWebpagesDb.instance;
    }
    /**
   * Add or update a cluster in chrome.storage.local
   */ async addClusters(clusters) {
        const previousClusters = await this.getAllClustersAsMap();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    async setClusters(clusters) {
        const previousClusters = new Map();
        clusters.map((clusterDetails)=>previousClusters.set(clusterDetails.name, clusterDetails));
        await this.saveClustersToStorage(previousClusters);
    }
    /**
   * Retrieve all clusters from chrome.storage.local
   */ async getAllClusters() {
        const clusters = await this.getAllClustersAsMap();
        return Array.from(clusters.values());
    }
    /**
   * Internal: Retrieve all clusters as a Map
   */ async getAllClustersAsMap() {
        return new Promise((resolve)=>{
            chrome.storage.local.get([
                ClusteredWebpagesDb.STORAGE_KEY
            ], (result)=>{
                const stored = result[ClusteredWebpagesDb.STORAGE_KEY] || {};
                const map = new Map(Object.entries(stored));
                resolve(map);
            });
        });
    }
    /**
   * Internal: Save clusters map back to chrome.storage.local
   */ async saveClustersToStorage(clusters) {
        return new Promise((resolve)=>{
            const obj = Object.fromEntries(clusters);
            chrome.storage.local.set({
                [ClusteredWebpagesDb.STORAGE_KEY]: obj
            }, ()=>resolve());
        });
    }
    constructor(){}
}
_define_property_define_property(ClusteredWebpagesDb, "instance", void 0);
_define_property_define_property(ClusteredWebpagesDb, "STORAGE_KEY", 'clusters');

;// CONCATENATED MODULE: ./src/common/llm-functions/document-cluster-selection.ts

const document_cluster_selection_clusterSchema = {
    type: 'object',
    properties: {
        assignedCluster: {
            type: 'string'
        },
        confidence: {
            type: 'number'
        }
    }
};
async function findClusterForDocument(contentSummary, clusters) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    // const clustersAsPoints = clusters.reduce((acc, cluster, index) => {
    //   return `${acc}\n${index}. ${cluster}`;
    // }, '');
    const clusterDocumentMatchingPrompt = `Given the following thematic clusters:
    ${clusters}

  And this document:
  "${contentSummary}

  Assign the document to the most relevant thematic cluster by reasoning about the main topic.
`;
    const result = await session.prompt(clusterDocumentMatchingPrompt, {
        responseConstraint: document_cluster_selection_clusterSchema
    });
    console.log('Relevant cluster', result, contentSummary);
    const parsedResult = JSON.parse(result);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/common/messaging/history-collection-channel/history-collection-channel.ts

function makeHistoryCollectionBoardChannel() {
    return newMessageChannel('HISTORY_COLLECTION_CARD');
}

;// CONCATENATED MODULE: ./src/common/constants/internet-cluster-themes.ts
const internetThemes = [
    {
        id: 1,
        theme: 'Information Seeking',
        icon: 'search',
        colors: {
            primary: '#1565C0',
            accent: '#42A5F5',
            textOnAccent: '#FFFFFF'
        },
        description: 'Users search for knowledge such as news updates, tutorials, documentation, or research content to satisfy curiosity or accomplish specific tasks.'
    },
    {
        id: 2,
        theme: 'Entertainment Consumption',
        icon: 'movie',
        colors: {
            primary: '#D32F2F',
            accent: '#FF5252',
            textOnAccent: '#FFFFFF'
        },
        description: 'Includes watching videos, browsing social media, listening to music, reading memes, or playing online games for relaxation and leisure.'
    },
    {
        id: 3,
        theme: 'Shopping and Product Research',
        icon: 'shopping_cart',
        colors: {
            primary: '#2E7D32',
            accent: '#66BB6A',
            textOnAccent: '#FFFFFF'
        },
        description: 'Users explore e-commerce sites, compare prices, read product reviews, and look for deals before making purchasing decisions.'
    },
    {
        id: 4,
        theme: 'Social Connection',
        icon: 'chat',
        colors: {
            primary: '#7B1FA2',
            accent: '#AB47BC',
            textOnAccent: '#FFFFFF'
        },
        description: 'Covers engagement on social media platforms, messaging apps, or online communities to stay connected with friends, family, and interest groups.'
    },
    {
        id: 5,
        theme: 'Learning and Skill Development',
        icon: 'school',
        colors: {
            primary: '#F9A825',
            accent: '#FFD54F',
            textOnAccent: '#212121'
        },
        description: 'Users visit educational platforms, online courses, or tutorials to build professional skills or learn new topics for personal growth.'
    },
    {
        id: 6,
        theme: 'Productivity and Work-Related Tasks',
        icon: 'work',
        colors: {
            primary: '#37474F',
            accent: '#90A4AE',
            textOnAccent: '#FFFFFF'
        },
        description: 'Involves browsing tools, documentation, and platforms used for collaboration, project management, and professional work.'
    },
    {
        id: 7,
        theme: 'Personal Expression and Creation',
        icon: 'palette',
        colors: {
            primary: '#EF6C00',
            accent: '#FFA726',
            textOnAccent: '#212121'
        },
        description: 'Users express creativity through blogging, digital art, content creation, or sharing personal opinions online.'
    }
];

;// CONCATENATED MODULE: ./src/common/history-collection-card/history-collection-card.ts




class HistoryCollectionBoard {
    static getInstance() {
        if (!HistoryCollectionBoard.instance) {
            HistoryCollectionBoard.instance = new HistoryCollectionBoard();
        }
        return HistoryCollectionBoard.instance;
    }
    async getHistoryBoard() {
        const clusters = await ClusteredWebpagesDb.getInstance().getAllClusters();
        const historyCollectionCards = await Promise.all(clusters.map(async (cluster)=>{
            const tabs = await TabContentDb.getInstance().getAllTabsOfCluster(cluster.name);
            console.log('History card', {
                clusters,
                tabs
            });
            if (tabs.length > 0) {
                const historyCollectionCard = await this.getHistoryCollectionCard(cluster, tabs);
                return {
                    clusterName: cluster.name,
                    historyCollectionCard
                };
            }
        }));
        const board = historyCollectionCards.filter((t)=>t !== undefined).reduce((acc, param)=>{
            let { clusterName, historyCollectionCard } = param;
            return {
                ...acc,
                [clusterName]: historyCollectionCard
            };
        }, {});
        return board;
    }
    async getHistoryCollectionCard(cluster, webPageDetails) {
        const collectionThemeDetails = internetThemes.find((themeDetails)=>themeDetails.theme === cluster.collectionTheme) || internetThemes["0"];
        const cardTheme = {
            themeIcon: collectionThemeDetails.icon,
            size: 'M',
            primaryColor: collectionThemeDetails.colors.primary,
            accentColor: collectionThemeDetails.colors.accent,
            textColor: collectionThemeDetails.colors.textOnAccent
        };
        // FIXME: populate this properly
        return {
            cardTitle: cluster.name,
            cardDescription: cluster.description,
            theme: cardTheme,
            webPageDetails: webPageDetails.map((param)=>{
                let { url } = param;
                return {
                    domain: new URL(url).hostname,
                    favicon: '',
                    theme: {
                        id: '',
                        name: '',
                        description: ''
                    },
                    navigateUrl: url
                };
            })
        };
    }
    constructor(){}
}
_define_property_define_property(HistoryCollectionBoard, "instance", void 0);

;// CONCATENATED MODULE: ./src/common/llm-functions/determine-cluster-theme.ts


const clusterThemeSchema = {
    type: 'object',
    properties: {
        theme: {
            type: 'string'
        },
        confidence: {
            type: 'string'
        }
    }
};
async function determineClusterTheme(clusterDetails) {
    if (!checkAvailability()) {
        console.error('Unable to extract themes from the content');
    }
    const session = await createPromptSession();
    const clusterThemePrompt = `Given the following list of themes common to webpages on internet:
      ${JSON.stringify(internetThemes)}


      And this cluster:
      "${JSON.stringify(clusterDetails)}

      Assign the cluster to the most related theme by reasoning on the coherence between the theme description and cluster description.
    `;
    const result = await session.prompt(clusterThemePrompt, {
        responseConstraint: clusterThemeSchema
    });
    const parsedResult = JSON.parse(result);
    console.log('Cluster Theme', parsedResult);
    return parsedResult;
}

;// CONCATENATED MODULE: ./src/app/worker/handlers/dashboard-handler.ts








class DashboardHandler {
    static getInstance() {
        if (!DashboardHandler.instance) {
            DashboardHandler.instance = new DashboardHandler();
        }
        return DashboardHandler.instance;
    }
    async updateThematicClusters() {
        const themes = await TabContentDb.getInstance().getAllThemes();
        // generate new clusters
        const clusters = await determineThematicClustering(themes);
        const updatedClustersWithTheme = await Promise.all(clusters.map(async (clusterDetails)=>{
            const clusterCollectionTheme = await determineClusterTheme(clusterDetails);
            return {
                ...clusterDetails,
                collectionTheme: clusterCollectionTheme.theme
            };
        }));
        await ClusteredWebpagesDb.getInstance().setClusters(updatedClustersWithTheme);
        console.log('Clusters', clusters);
        const allTabs = await TabContentDb.getInstance().getAllTabs();
        await Promise.all(allTabs.map(async (url)=>{
            const tabDetails = await TabContentDb.getInstance().getTabContentByUrl(url);
            if (tabDetails) {
                const clusterNames = (await ClusteredWebpagesDb.getInstance().getAllClusters()).map((clusterDetails)=>clusterDetails.name);
                const documentCluster = await findClusterForDocument(tabDetails.contentSummary, clusterNames);
                await TabContentDb.getInstance().addClusterToDocument(tabDetails.url, documentCluster.assignedCluster);
            }
        }));
        this.publishBoardUpdates();
    }
    async publishBoardUpdates() {
        const historyCollectionBoard = await HistoryCollectionBoard.getInstance().getHistoryBoard();
        // FIXME: sometimes it returns undefined, find the root cause of it
        if (HistoryCollectionBoard) {
            await this.historyCollectionBoardChannel.send({}, {
                clusters: historyCollectionBoard
            });
        }
    }
    constructor(){
        _define_property_define_property(this, "historyCollectionBoardChannel", void 0);
        this.historyCollectionBoardChannel = makeHistoryCollectionBoardChannel();
    }
}
_define_property_define_property(DashboardHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/handlers/tab-content.handler.ts







class TabContentHandler {
    static getInstance() {
        if (!TabContentHandler.instance) {
            TabContentHandler.instance = new TabContentHandler();
        }
        return TabContentHandler.instance;
    }
    async startTabContentReader() {
        // setup listener to capture tab navigation
        //
        console.log('Starting tab content reader');
        await ChromeExtensionConnector.getInstance().onTabNavigate(async (tabDetails)=>{
            const tabId = tabDetails.tabId;
            const url = tabDetails.url;
            if (!url) {
                return;
            }
            /**
         * Check and process if the tab is seen first time
         */ const tabAlreadyProcessed = await TabContentDb.getInstance().getTabContentByUrl(url);
            if (![
                url.startsWith('chrome://'),
                url.startsWith('chrome-extension://')
            ].some(Boolean) && !tabAlreadyProcessed) {
                console.log('Executing grabber on tab', tabId);
                await ChromeExtensionConnector.getInstance().injectScriptToTab('static/js/tab-content-grabber.js', tabId);
            }
        });
        const tabSummarizationMessageChannel = makeTabSummarizationChannel();
        await tabSummarizationMessageChannel.subscribe({}, async (context, payload)=>{
            console.log('Received content', payload);
            await TabContentDb.getInstance().addTabContent({
                ...payload
            });
            const clusterNames = (await ClusteredWebpagesDb.getInstance().getAllClusters()).map((clusterDetails)=>clusterDetails.name);
            /**
         * Find an existing cluster, if not found then buffer it for processing
         */ if (clusterNames.length > 2) {
                console.log('finding cluster');
                const documentCluster = await findClusterForDocument(payload.contentSummary, clusterNames);
                console.log({
                    documentCluster
                });
                if (documentCluster.confidence > 0.9) {
                    await TabContentDb.getInstance().addClusterToDocument(payload.url, documentCluster.assignedCluster);
                    await DashboardHandler.getInstance().publishBoardUpdates();
                } else {
                    console.log('Low ranking document, not added to a cluster');
                    this.lowRankingTabsCapturedTotal += 1;
                }
            }
            await this.bufferedClustering();
        });
    }
    async bufferedClustering() {
        if (this.lowRankingTabsCapturedTotal > 3) {
            console.log('Starting thematic clustering updated');
            this.lowRankingTabsCapturedTotal = 0;
            await DashboardHandler.getInstance().updateThematicClusters();
        }
    }
    constructor(){
        _define_property_define_property(this, "lowRankingTabsCapturedTotal", void 0);
        this.lowRankingTabsCapturedTotal = 0;
    }
}
_define_property_define_property(TabContentHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/worker/main.ts

console.log('background worker is starting up');
(async ()=>{
    // await ChromeAIHandler.getInstance().setupAI();
    // await HistoryCollector.getInstance().syncHistory();
    // await HistoryCollector.getInstance().collectHistory();
    await TabContentHandler.getInstance().startTabContentReader();
})();

})()
;
//# sourceMappingURL=background.js.map