(() => { // webpackBootstrap
"use strict";
var __webpack_modules__ = ({
433: (function (__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {

// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(259);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@19.2.0/node_modules/react/index.js
var react = __webpack_require__(363);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-dom@19.2.0_react@19.2.0/node_modules/react-dom/client.js
var client = __webpack_require__(546);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1/node_modules/react-redux/dist/react-redux.mjs
var react_redux = __webpack_require__(120);
;// CONCATENATED MODULE: ./src/app/popup-ui/index.css
// extracted by css-extract-rspack-plugin

// EXTERNAL MODULE: ./node_modules/.pnpm/@reduxjs+toolkit@2.9.2_react-redux@9.2.0_@types+react@19.2.2_react@19.2.0_redux@5.0.1__react@19.2.0/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var redux_toolkit_modern = __webpack_require__(963);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/effects/dist/redux-saga-core-effects.esm.js
var redux_saga_core_effects_esm = __webpack_require__(827);
// EXTERNAL MODULE: ./node_modules/.pnpm/@redux-saga+core@1.4.2/node_modules/@redux-saga/core/dist/redux-saga-core.esm.js
var redux_saga_core_esm = __webpack_require__(287);
// EXTERNAL MODULE: ./node_modules/.pnpm/reselect@5.1.1/node_modules/reselect/dist/reselect.mjs
var reselect = __webpack_require__(526);
;// CONCATENATED MODULE: ./src/app/popup-ui/middleware/app/app.slice.ts

const APP_FEATURE_KEY = 'app';
const initialAppState = {
    page: 'HOME'
};
const appSlice = (0,redux_toolkit_modern/* .createSlice */.Z0)({
    name: APP_FEATURE_KEY,
    initialState: initialAppState,
    reducers: {
        setPage (state, action) {
            return {
                ...state,
                page: action.payload
            };
        }
    }
});
const appSliceActions = appSlice.actions;
const appSliceReducer = appSlice.reducer;
const getAppState = (rootState)=>rootState[APP_FEATURE_KEY];
/* Selectors */ const appSliceSelectors = {
    getCurrentPage: (0,reselect/* .createSelector */.Mz)(getAppState, (state)=>state.page)
};

;// CONCATENATED MODULE: ./src/app/popup-ui/middleware/store.ts




const sagaMiddleware = (0,redux_saga_core_esm/* ["default"] */.Ay)();
const store_store = (0,redux_toolkit_modern/* .configureStore */.U1)({
    reducer: {
        [APP_FEATURE_KEY]: appSliceReducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(sagaMiddleware),
    devTools: true
});
function* rootSaga() {
    yield (0,redux_saga_core_effects_esm/* .all */.Q7)([]);
}
sagaMiddleware.run(rootSaga);
function getStore() {
    return store_store;
}

;// CONCATENATED MODULE: ./src/app/popup-ui/components/popup.tsx


function Popup() {
    function handleOpenSearchDashbooard() {
        chrome.tabs.create({
            url: chrome.runtime.getURL('search-dashboard.html')
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col items-center justify-center min-h-screen w-[320px] bg-white text-gray-800 p-6 space-y-4 shadow-lg rounded-lg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsx)("h1", {
                className: "text-2xl font-semibold text-indigo-600",
                children: "Reverie"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("p", {
                className: "text-center text-sm text-gray-600",
                children: "Explore your browsing memories and rediscover your moments of curiosity."
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsx)("button", {
                className: "px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-md transition-all duration-200 shadow-md",
                onClick: handleOpenSearchDashbooard,
                children: "Open Reverie"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/app/popup-ui/main.tsx







const container = document.getElementById('root');
if (container) {
    const store = getStore();
    const root = (0,client.createRoot)(container);
    root.render(/*#__PURE__*/ (0,jsx_runtime.jsx)(react.StrictMode, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsx)(react_redux/* .Provider */.Kq, {
            store: store,
            children: /*#__PURE__*/ (0,jsx_runtime.jsx)(Popup, {})
        })
    }));
}


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/on_chunk_loaded
(() => {
var deferred = [];
__webpack_require__.O = (result, chunkIds, fn, priority) => {
	if (chunkIds) {
		priority = priority || 0;
		for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
			deferred[i] = deferred[i - 1];
		deferred[i] = [chunkIds, fn, priority];
		return;
	}
	var notFulfilled = Infinity;
	for (var i = 0; i < deferred.length; i++) {
		var [chunkIds, fn, priority] = deferred[i];
		var fulfilled = true;
		for (var j = 0; j < chunkIds.length; j++) {
			if (
				(priority & (1 === 0) || notFulfilled >= priority) &&
				Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))
			) {
				chunkIds.splice(j--, 1);
			} else {
				fulfilled = false;
				if (priority < notFulfilled) notFulfilled = priority;
			}
		}
		if (fulfilled) {
			deferred.splice(i--, 1);
			var r = fn();
			if (r !== undefined) result = r;
		}
	}
	return result;
};

})();
// webpack/runtime/jsonp_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"788": 0,};
      __webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
// install a JSONP callback for chunk loading
var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
	var [chunkIds, moreModules, runtime] = data;
	// add "moreModules" to the modules object,
	// then flag all "chunkIds" as loaded and fire callback
	var moduleId, chunkId, i = 0;
	if (chunkIds.some((id) => (installedChunks[id] !== 0))) {
		for (moduleId in moreModules) {
			if (__webpack_require__.o(moreModules, moduleId)) {
				__webpack_require__.m[moduleId] = moreModules[moduleId];
			}
		}
		if (runtime) var result = runtime(__webpack_require__);
	}
	if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
	for (; i < chunkIds.length; i++) {
		chunkId = chunkIds[i];
		if (
			__webpack_require__.o(installedChunks, chunkId) &&
			installedChunks[chunkId]
		) {
			installedChunks[chunkId][0]();
		}
		installedChunks[chunkId] = 0;
	}
	return __webpack_require__.O(result);
};

var chunkLoadingGlobal = self["webpackChunkreverie"] = self["webpackChunkreverie"] || [];
chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));

})();
/************************************************************************/
// startup
// Load entry module and return exports
// This entry module depends on other loaded chunks and execution need to be delayed
var __webpack_exports__ = __webpack_require__.O(undefined, ["783", "527", "751"], function() { return __webpack_require__(433) });
__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
})()
;
//# sourceMappingURL=popup.js.map