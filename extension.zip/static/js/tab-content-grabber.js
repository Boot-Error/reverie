(() => { // webpackBootstrap
var __webpack_modules__ = ({
626: (function (module) {
var populateChar = function(ch, amount){
	var result = "";
	for(var i=0; i<amount; i += 1){
		result += ch;
	}
	return result;
};

function htmlToPlainText(htmlText, styleConfig) {

	// define default styleConfig
	var linkProcess = null;
	var imgProcess = null;
	var headingStyle = "underline"; // hashify, breakline
	var listStyle = "indention"; // indention, linebreak
	var uIndentionChar = "-";
	var listIndentionTabs = 3;
	var oIndentionChar = "-";
	var keepNbsps = false;

	// or accept user defined config
	if(!!styleConfig){
		if(typeof styleConfig.linkProcess === "function") {
			linkProcess = styleConfig.linkProcess;
		}
		if(typeof styleConfig.imgProcess === "function") {
			imgProcess = styleConfig.imgProcess;
		}
		if(!!styleConfig.headingStyle) {
			headingStyle = styleConfig.headingStyle;
		}
		if(!!styleConfig.listStyle) {
			listStyle = styleConfig.listStyle;
		}
		if(!!styleConfig.uIndentionChar) {
			uIndentionChar = styleConfig.uIndentionChar;
		}
		if(!!styleConfig.listIndentionTabs) {
			listIndentionTabs = styleConfig.listIndentionTabs;
		}
		if(!!styleConfig.oIndentionChar) {
			oIndentionChar = styleConfig.oIndentionChar;
		}
		if(!!styleConfig.keepNbsps) {
			keepNbsps = styleConfig.keepNbsps;
		}
	}

	var uIndention = populateChar(uIndentionChar, listIndentionTabs);

	// removel all \n linebreaks
	var tmp = String(htmlText).replace(/\n|\r/g, " ");

	// remove everything before and after <body> tags including the tag itself
	const bodyEndMatch = tmp.match(/<\/body>/i);
	if (bodyEndMatch) {
		tmp = tmp.substring(0, bodyEndMatch.index);
	}
	const bodyStartMatch = tmp.match(/<body[^>]*>/i);
	if (bodyStartMatch) {
		tmp = tmp.substring(bodyStartMatch.index + bodyStartMatch[0].length, tmp.length);
	}

	// remove inbody scripts and styles
	tmp = tmp.replace(/<(script|style)( [^>]*)*>((?!<\/\1( [^>]*)*>).)*<\/\1>/gi, "");

	// remove all tags except that are being handled separately
	tmp = tmp.replace(/<(\/)?((?!h[1-6]( [^>]*)*>)(?!img( [^>]*)*>)(?!a( [^>]*)*>)(?!ul( [^>]*)*>)(?!ol( [^>]*)*>)(?!li( [^>]*)*>)(?!p( [^>]*)*>)(?!div( [^>]*)*>)(?!td( [^>]*)*>)(?!br( [^>]*)*>)[^>\/])[^<>]*>/gi, "");

	// remove or replace images - replacement texts with <> tags will be removed also, if not intentional, try to use other notation
	tmp = tmp.replace(/<img([^>]*)>/gi, function(str, imAttrs) {
		var imSrc = "";
		var imAlt = "";
		var imSrcResult = (/src="([^"]*)"/i).exec(imAttrs);
		var imAltResult = (/alt="([^"]*)"/i).exec(imAttrs);
		if(imSrcResult !== null){
			imSrc = imSrcResult[1];
		}
		if(imAltResult !== null){
			imAlt = imAltResult[1];
		}
		if(typeof(imgProcess) === "function") {
			return imgProcess(imSrc, imAlt);
		}
		if(imAlt === ""){
			return "![image] ("+ imSrc + ")";
		}
		return "![" + imAlt+"] ("+ imSrc + ")";
	});


	function createListReplaceCb() {
		return function(match, listType, listAttributes, listBody) {
			var liIndex = 0;
			if(listAttributes && /start="([0-9]+)"/i.test(listAttributes)) {
				liIndex = (/start="([0-9]+)"/i.exec(listAttributes)[1])-1;
			}
			var plainListItem = "<p>" + listBody.replace(/<li[^>]*>(((?!<li[^>]*>)(?!<\/li>).)*)<\/li>/gi, function(str, listItem) {
				var actSubIndex = 0;
				var plainListLine = listItem.replace(/(^|(<br \/>))(?!<p>)/gi, function(){
					if(listType === "o" && actSubIndex === 0){
						liIndex += 1;
						actSubIndex += 1;
						return "<br />" + liIndex + populateChar(oIndentionChar, listIndentionTabs-(String(liIndex).length));
					}
					return "<br />" + uIndention;
				});
				return plainListLine;
			})+"</p>";
			return plainListItem;
		};
	}

	// handle lists
	if(listStyle === "linebreak"){
		tmp = tmp.replace(/<\/?ul[^>]*>|<\/?ol[^>]*>|<\/?li[^>]*>/gi, "\n");
	}
	else if(listStyle === "indention"){
		while( /<(o|u)l[^>]*>(.*)<\/\1l>/gi.test(tmp)){
			tmp = tmp.replace(/<(o|u)l([^>]*)>(((?!<(o|u)l[^>]*>)(?!<\/(o|u)l>).)*)<\/\1l>/gi, createListReplaceCb());
		}
	}

	// handle headings
	if(headingStyle === "linebreak") {
		tmp = tmp.replace(/<h([1-6])[^>]*>([^<]*)<\/h\1>/gi, "\n$2\n");
	}
	else if(headingStyle === "underline") {
		tmp = tmp.replace(/<h1[^>]*>(((?!<\/h1>).)*)<\/h1>/gi, function(str, p1) {
			return "\n&nbsp;\n" + p1 + "\n" + populateChar("=", p1.length) + "\n&nbsp;\n";
		});
		tmp = tmp.replace(/<h2[^>]*>(((?!<\/h2>).)*)<\/h2>/gi, function(str, p1) {
			return "\n&nbsp;\n" + p1 + "\n" + populateChar("-", p1.length) + "\n&nbsp;\n";
		});
		tmp = tmp.replace(/<h([3-6])[^>]*>(((?!<\/h\1>).)*)<\/h\1>/gi, function(str, p1, p2) {
			return "\n&nbsp;\n" + p2 + "\n&nbsp;\n";
		});
	}
	else if(headingStyle === "hashify") {
		tmp = tmp.replace(/<h([1-6])[^>]*>([^<]*)<\/h\1>/gi, function(str, p1, p2) {
			return "\n&nbsp;\n" + populateChar("#", p1) + " " + p2 + "\n&nbsp;\n";
		});
	}

	// replace <br>s, <td>s, <divs> and <p>s with linebreaks
	tmp = tmp.replace(/<br( [^>]*)*>|<p( [^>]*)*>|<\/p( [^>]*)*>|<div( [^>]*)*>|<\/div( [^>]*)*>|<td( [^>]*)*>|<\/td( [^>]*)*>/gi, "\n");

	// replace <a href>b<a> links with b (href) or as described in the linkProcess function
	tmp = tmp.replace(/<a[^>]*href="([^"]*)"[^>]*>([^<]+)<\/a[^>]*>/gi, function(str, href, linkText) {
		if(typeof linkProcess === "function") {
			return linkProcess(href, linkText);
		}
		return " [" + linkText+"] ("+ href + ") ";
	});

	// remove whitespace from empty lines excluding nbsp
	tmp = tmp.replace(/\n[ \t\f]*/gi, "\n");

	// remove duplicated empty lines
	tmp = tmp.replace(/\n\n+/gi, "\n");

	if (keepNbsps) {
		// remove duplicated spaces including non braking spaces
		tmp = tmp.replace(/( |\t)+/gi, " ");
		tmp = tmp.replace(/&nbsp;/gi, " ");
	} else {
		// remove duplicated spaces including non braking spaces
		tmp = tmp.replace(/( |&nbsp;|\t)+/gi, " ");
	}

	// remove line starter spaces
	tmp = tmp.replace(/\n +/gi, "\n");

	// remove content starter spaces
	tmp = tmp.replace(/^ +/gi, "");

	// remove first empty line
	while(tmp.indexOf("\n") === 0){
		tmp = tmp.substring(1);
	}

	// put a new line at the end
	if(tmp.length === 0 || tmp.lastIndexOf("\n") !== tmp.length-1){
		tmp += "\n";
	}

	return tmp;
}


(function (name, definition){
	if (this && typeof this.define === "function"){ // AMD
		this.define(definition);
	} else if ( true && module.exports) { // Node.js
		module.exports = definition();
	} else { // Browser
		var theModule = definition();
		var global = this;
		var old = global[name];
		theModule.noConflict = function () {
			global[name] = old;
			return theModule;
		};
		global[name] = theModule;
	}
})("createTextVersion", function () {
	return htmlToPlainText;
});


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

/************************************************************************/
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ./node_modules/.pnpm/@swc+helpers@0.5.17/node_modules/@swc/helpers/esm/_define_property.js
function _define_property_define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });
    } else obj[key] = value;

    return obj;
}


// EXTERNAL MODULE: ./node_modules/.pnpm/textversionjs@1.1.3/node_modules/textversionjs/src/textversion.js
var textversion = __webpack_require__(626);
;// CONCATENATED MODULE: ./src/common/messaging/messaging.ts

class ChromeMessagingPipe {
    static new(params) {
        const pipe = new ChromeMessagingPipe(params.name);
        return pipe;
    }
    subscribe(callback) {
        this.port.onMessage.addListener((message)=>{
            callback(message);
        });
    }
    publish(message) {
        this.port.postMessage(message);
    }
    close() {
        this.port.disconnect();
    }
    constructor(pipeName){
        _define_property(this, "port", void 0);
        const port = chrome.runtime.connect({
            name: pipeName
        });
        this.port = port;
    }
}
function newMessageChannel(name) {
    let onMessageCallback;
    return {
        name,
        async send (context, message) {
            const channelMessage = {
                name,
                payload: message
            };
            await chrome.runtime.sendMessage(channelMessage);
        },
        async subscribe (context, callback) {
            onMessageCallback = (message, sender)=>{
                (async ()=>{
                    const payload = message.payload;
                    if (message.name === name) {
                        await callback({
                            sender
                        }, payload);
                    }
                })();
            };
            chrome.runtime.onMessage.addListener(onMessageCallback);
        },
        async unsubscribe () {
            chrome.runtime.onMessage.removeListener(onMessageCallback);
        }
    };
}

;// CONCATENATED MODULE: ./src/common/messaging/tab-summarization-channel/tab-summarization-channel.ts

function makeTabSummarizationChannel() {
    return newMessageChannel('TAB_SUMMARIZATION');
}

;// CONCATENATED MODULE: ./src/app/tab-content-grabber/handlers/tab-content-reader.handler.ts



class TabContentReaderHandler {
    static getInstance() {
        if (!TabContentReaderHandler.instance) {
            TabContentReaderHandler.instance = new TabContentReaderHandler();
        }
        return TabContentReaderHandler.instance;
    }
    async captureAndPublishReadableContent() {
        try {
            const url = window.location.href;
            console.log({
                url
            });
            const bodyInnerText = document.getElementsByTagName('body')[0].innerText;
            const contentText = textversion(bodyInnerText);
            console.log(contentText);
            const contentSummary = await this.summarizeText(contentText);
            const contentThemes = await this.extractThemes(contentText);
            const tabSummarizationChannel = makeTabSummarizationChannel();
            await tabSummarizationChannel.send({}, {
                url: window.location.href,
                contentSummary: contentSummary.contentSummary,
                contentThemes: contentThemes.themes
            });
        } catch (err) {
            console.error(err, err === null || err === void 0 ? void 0 : err.stackTrace);
        }
    }
    /**
   *
   * Summarises the content using text summarizer API
   *
   * @param content
   * @returns
   */ async summarizeText(content) {
        const availability = await Summarizer.availability();
        if (availability !== 'available') {
            console.error('Unable to summarize content due to ', availability);
        }
        const options = {
            sharedContext: 'This is a scientific article',
            type: 'key-points',
            format: 'markdown',
            length: 'medium',
            outputLanguage: 'en',
            expectedInputLanguages: [
                'en'
            ],
            expectedContextLanguages: [
                'en'
            ],
            monitor (m) {
                m.addEventListener('downloadprogress', (e)=>{
                    console.log(`Downloaded ${e.loaded * 100}%`);
                });
            }
        };
        const summarizer = await Summarizer.create(options);
        const response = await summarizer.summarize(content, {
            context: 'This is an extracted text of a website'
        });
        console.log({
            response
        });
        return {
            contentSummary: response
        };
    }
    async extractThemes(content) {
        const availability = await LanguageModel.availability();
        if (availability !== 'available') {
            console.error('Unable to extract themes from the content due to ', availability);
        }
        const themeSchema = {
            type: 'object',
            properties: {
                themes: {
                    type: 'array',
                    items: {
                        type: 'string'
                    }
                }
            }
        };
        const session = await LanguageModel.create({
            monitor (m) {
                m.addEventListener('downloadprogress', (e)=>{
                    console.log(`Downloaded ${e.loaded * 100}%`);
                });
            }
        });
        const themeExtractionPrompt = `You are an expert in content analysis.
    Read the following text and return 2 to 4 high-level themes capturing the main ideas.
    `;
        const result = await session.prompt(`${themeExtractionPrompt} \n\n${content}`, {
            responseConstraint: themeSchema
        });
        console.log('Themes', result);
        const parsedResponse = JSON.parse(result);
        return {
            themes: parsedResponse.themes
        };
    }
    constructor(){}
}
_define_property_define_property(TabContentReaderHandler, "instance", void 0);

;// CONCATENATED MODULE: ./src/app/tab-content-grabber/main.ts

/**
 * This script is injected to each tab to grab textual information for the summarization and processing
 */ console.log('🚀 Content script injected!');
document.body.style.outline = '2px solid limegreen'; // example action
(async ()=>{
    console.log('Extension is loaded');
    await TabContentReaderHandler.getInstance().captureAndPublishReadableContent();
})();

})();

})()
;
//# sourceMappingURL=tab-content-grabber.js.map